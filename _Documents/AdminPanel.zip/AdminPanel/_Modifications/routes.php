<?php

$installClasses = ['PanelController::class', 'PanelPageController::class', 'PanelToolsController::class', 'PanelAjaxController::class'];

$installUses = <<<PHP
use App\\Controller\\PanelController;
use App\\Controller\\PanelPageController;
use App\\Controller\\PanelToolsController;
use App\\Controller\\PanelAjaxController;
PHP;

$installRoutes = <<<PHP
// Administration panel routes
    \$router->addRoute(\$panel, [PanelController::class, 'index'], 'panel');
    \$router->addRoute(\$panel . '/manage-pages', [PanelPageController::class, 'managePages'], 'panel_manage_pages');
    \$router->addRoute(\$panel . '/create-edit-page', [PanelPageController::class, 'createOrEditPage'], 'panel_create_edit_page');
    \$router->addRoute(\$panel . '/ajax-delete-page', [PanelPageController::class, 'ajaxDeletePage'], 'panel_ajax_delete_page');
    \$router->addRoute(\$panel . '/error-log', [PanelToolsController::class, 'errorLog'], 'panel_error_log');
    \$router->addRoute(\$panel . '/ajax-upload-image', [PanelAjaxController::class, 'ajaxUploadImage'], 'panel_ajax_upload_image');
    \$router->addRoute(\$panel . '/ajax-delete-image', [PanelAjaxController::class, 'ajaxDeleteImage'], 'panel_ajax_delete_image');
PHP;

$installValues = <<<PHP
\$panel = '/' . getenv('APP_PANEL');
PHP;
