/* DataTable Setting One */
$(document).ready(function() {
	$('#datatableOne').dataTable({
		pageLength: 10,
		columnDefs: [{
			targets: 'noSort',
			orderable: false,
		}],
		order: [[0, 'desc']],
		language: {
			"emptyTable": "Brak danych w tabeli",
			"infoEmpty": "Brak rekordów do wyświetlenia",
			"sLengthMenu": "Wyświetl _MENU_ rekordów",
			"sInfo": "Wyświetlono od _START_ do _END_ z _TOTAL_ rekordów",
			"sSearch": "Szukaj",
		},
		drawCallback: function() {
			$('[data-toggle="tooltip"]').tooltip();
		},
	});
});
