/**
* Author: Design by Malina
*/

(function() {
  "use strict";

  // Sprawdzenie, czy appUrl jest zdefiniowane globalnie
  if (typeof window.appUrl === 'undefined') {
    console.error("Zmienna 'appUrl' nie jest zdefiniowana w szablonie. Ustawiono domyślną wartość '[URL]'.");
    window.appUrl = '[URL]'; // Ustawienie domyślnej wartości
  }

  const useDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;

  // Konfiguracja TinyMCE
  const tinymceConfig = {
    selector: '#fieldContent', // textarea.tinymceEditor
    language: 'pl',
    plugins: 'preview importcss searchreplace autolink autosave save directionality code visualblocks visualchars fullscreen image link media codesample table charmap pagebreak nonbreaking anchor insertdatetime advlist lists wordcount help charmap quickbars emoticons accordion',
    menubar: 'file edit view insert format tools table help',
    toolbar: "undo redo | accordion accordionremove | blocks fontfamily fontsize | bold italic underline strikethrough | align numlist bullist | customImageButton | link image | table media | lineheight outdent indent| forecolor backcolor removeformat | charmap emoticons | code fullscreen preview | print | pagebreak anchor codesample | ltr rtl",
    autosave_ask_before_unload: true,
    autosave_interval: '30s',
    autosave_prefix: '{path}{query}-{id}-',
    autosave_restore_when_empty: false,
    autosave_retention: '2m',
    image_advtab: true,
    height: 500,
    image_caption: true,
    quickbars_selection_toolbar: 'bold italic | quicklink h2 h3 blockquote quickimage quicktable',
    toolbar_mode: 'sliding',
    contextmenu: 'link image table',
    skin: useDarkMode ? 'oxide-dark' : 'oxide',
    content_css: useDarkMode ? 'dark' : 'default',
    content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px }',
    file_picker_callback: (callback, value, meta) => {
      if (meta.filetype === 'image') {
        callback('https://www.google.com/logos/google.jpg', { alt: 'Opis obrazka' });
      }
    },
	  /* Example 2: images_upload_url: '../images/blog/endpoint', // Endpoint do przesyłania obrazków
    relative_urls: false,
    remove_script_host: false,
    document_base_url: '../images/blog/photo', // Ścieżka bazowa do obrazków
    file_picker_callback: function (callback, value, meta) {
      // Integracja z menedżerem plików
      if (meta.filetype === 'image') {
        const input = document.createElement('input');
        input.setAttribute('type', 'file');
        input.setAttribute('accept', 'image/*');
        input.onchange = function () {
          const file = this.files[0];

          // Prześlij obrazek i uzyskaj jego URL
          const formData = new FormData();
          formData.append('file', file);

          fetch('../images/blog/editor', {
            method: 'POST',
            body: formData
          })
          .then(response => response.json())
          .then(data => callback(data.location)); // URL przesłanego obrazka
        };

        input.click();
      }
    }, */
	  // statusbar: false,
    formats: { // Formaty dla pogrubienia: <b> i <strong>
      bold: { inline: 'b' },
      strong: { inline: 'strong' }
    },
    indent: '    ', // Użyj czterech spacji dla wcięć
    indentation: '20px', // Szerokość wcięcia w edytorze
    preformatted: true, // Zachowaj formatowanie w elementach <pre>
	  entity_encoding: "raw", // Zachowuje znaki w formacie tekstowym
    entities: "160,nbsp", // Opcjonalnie: minimalizuje użycie encodowania znakow, spacja niełamliwa pozostaje encodowana
    document_base_url: window.appUrl, // Ustaw bazowy URL
    relative_urls: false, // Wymuś użycie pełnych adresów URL
    remove_script_host: false, // Zachowaj pełne adresy URL
    /*init_instance_callback: function (editor) {
      let content = editor.getContent();
      editor.setContent(content.replace(/\[URL\]/g, appUrl));
    },*/
    setup: function (editor) {
      // Dodanie przycisku do menadżera obrazów
      editor.ui.registry.addButton('customImageButton', {
        text: 'Obrazy',
        icon: 'image',
        onAction: function () {
          // Otwórz modal
          const imageModal = new bootstrap.Modal(document.getElementById('imageModal'));
          imageModal.show();

          // Nasłuchiwanie kliknięcia na przycisk wstawienia obrazu
          const tableBody = document.getElementById('rowTable');
          tableBody.addEventListener('click', function onSetImage(event) {
              const target = event.target.closest('.setImage');
              if (target) {
                  const imageUrl = target.getAttribute('data-text');
                  editor.insertContent(`<img src="${imageUrl}" alt="Obraz">`); // Wstaw obraz do edytora
                  imageModal.hide();
                  tableBody.removeEventListener('click', onSetImage);
              }
          });
        }
      });
      // Zamiana [URL] na window.appUrl w widoku edytora
      editor.on('PostProcess', function (e) {
        if (e.get) {
            // Przy pobieraniu treści z edytora przywróć [URL]
            e.content = e.content.replace(new RegExp(window.appUrl, 'g'), '[URL]');
        }
      });
      editor.on('BeforeSetContent', function (e) {
          // Przy ustawianiu treści w edytorze zamień [URL] na window.appUrl
          e.content = e.content.replace(/\[URL\]/g, window.appUrl);
      });
    },
  };

  // Funkcja do inicjalizacji TinyMCE
  function initializeTinyMCE() {
    tinymce.init(tinymceConfig);
  }

  // Inicjalizacja TinyMCE na starcie
  initializeTinyMCE();

  // Obsługa przełącznika
  document.getElementById('fieldSwitchEditor').addEventListener('change', function(event) {
    const isChecked = event.target.checked;

    if (isChecked) {
      initializeTinyMCE(); // Ponowna inicjalizacja z tą samą konfiguracją
    } else {
      tinymce.remove('#fieldContent'); // Wyłączanie edytora
    }
  });
})();