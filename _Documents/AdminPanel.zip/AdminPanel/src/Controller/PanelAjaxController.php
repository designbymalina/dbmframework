<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use App\Service\PanelAjaxService;
use Dbm\Classes\AdminBaseController;
use Dbm\Classes\Http\Request;
use Dbm\Classes\Http\Response;
use Dbm\Classes\Logs\Logger;
use Dbm\Interfaces\DatabaseInterface;
use Lib\Files\FileSystem;
use Lib\Upload\ResizeUploadImage;
use Exception;

class PanelAjaxController extends AdminBaseController
{
    private $service;
    private $filesystem;
    private $logger;

    public function __construct(DatabaseInterface $database)
    {
        parent::__construct($database);

        $this->service = new PanelAjaxService();
        $this->filesystem = new FileSystem();
        $this->logger = new Logger();
    }

    /**
     * @param Request $request
     * @return Response
     *
     * @Route("/ajax-upload-image")
     */
    public function ajaxUploadImage(Request $request): Response
    {
        try {
            // Walidacja typu
            $type = $request->getPost('type');
            if (empty($type)) {
                return Response::json(['success' => false, 'message' => "Wymagany jest typ żadania POST!"], 400);
            }

            // Pobranie ścieżki dla danego typu
            $pathImage = $this->service->getTypeModule($type);
            if (!$pathImage) {
                return Response::json(['success' => false, 'message' => "Nieprawidłowa ścieżka do wgrania obrazka!"], 400);
            }

            // Sprawdzenie przesłanego pliku
            $file = $request->getUploadedFile('file');
            if (empty($file)) {
                return Response::json(['success' => false, 'message' => "Proszę wybrać obraz do przesłania!"], 400);
            }

            // Przetwarzanie obrazu
            $imageUpload = new ResizeUploadImage();
            $arrayResult = $imageUpload->createImages($file, $pathImage);

            // Spójna odpowiedź
            return Response::json([
                'success' => $arrayResult['status'] === 'success',
                'message' => $arrayResult['status'] === 'success' ? "Obraz został pomyślnie przesłany." : $arrayResult['message'],
                'filename' => $arrayResult['data'] ?? null,
            ], $arrayResult['status'] === 'success' ? 200 : 500);
        } catch (Exception $exception) {
            $this->logger->critical($exception->getMessage(), ['exception' => $exception]);
            return Response::json(['success' => false, 'message' => "Wystąpił błąd serwera. Spróbuj ponownie później."], 500);
        }
    }

    /**
     * @param Request $request
     * @return Response
     *
     * @Route("/ajax-delete-image")
     */
    public function ajaxDeleteImage(Request $request): Response
    {
        try {
            // Pobierz parametry z żądania
            $file = $request->getPost('file');
            $type = $request->getPost('type');

            // Walidacja wejścia
            if (empty($file) || empty($type)) {
                return Response::json(['success' => false, 'message' => 'Nieprawidłowe dane wejściowe.'], 400);
            }

            // Określ ścieżki obrazów
            $pathImage = $this->service->getTypeModule($type);
            $pathsToDelete = [
                $pathImage . 'photo/' . $file,
                $pathImage . 'thumb/' . $file
            ];

            // Usuń pliki
            $deleteResult = $this->filesystem->fileMultiDelete($pathsToDelete);

            // Sprawdź wynik usuwania
            if ($deleteResult !== null) {
                return Response::json(['success' => false, 'message' => $deleteResult], 500);
            }

            return Response::json(['success' => true, 'message' => 'Obraz został pomyślnie usunięty.'], 200);
        } catch (Exception $exception) {
            $this->logger->critical('Błąd podczas usuwania obrazu.', [
                'error' => $exception->getMessage(),
                'trace' => $exception->getTraceAsString()
            ]);

            return Response::json([
                'success' => false,
                'message' => 'Wystąpił błąd serwera. Spróbuj ponownie później.'
            ], 500);
        }
    }
}
