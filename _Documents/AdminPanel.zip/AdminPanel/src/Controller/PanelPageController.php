<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use App\Form\PanelPageForm;
use App\Service\PanelPageService;
use Dbm\Classes\AdminBaseController;
use Dbm\Classes\Http\Request;
use Dbm\Classes\Http\Response;
use Dbm\Classes\Logs\Logger;
use Dbm\Interfaces\DatabaseInterface;
use Lib\Files\FileSystem;
use Psr\Http\Message\ResponseInterface;
use RuntimeException;
use Exception;

class PanelPageController extends AdminBaseController
{
    private const DIR_CONTENT = BASE_DIRECTORY . 'data/content/';
    private const DIR_IMG_PAGE = BASE_DIRECTORY . 'public/images/page/photo/';

    private $filesystem;
    private $service;
    private $form;
    private $logger;

    public function __construct(DatabaseInterface $database)
    {
        parent::__construct($database);

        $this->filesystem = new FileSystem();
        $this->logger = new Logger();
        $this->service = new PanelPageService($this->filesystem, $this->logger);
        $this->form = new PanelPageForm();
    }

    /**
     * @return ResponseInterface
     *
     * @Route("[panel]/manage-pages")
     */
    public function managePages(): ResponseInterface
    {
        $contentFiles = $this->filesystem->scanDirectory(self::DIR_CONTENT);

        return $this->render('panel/manage_pages.phtml', [
            'meta' => ['meta.title' => 'Strony - Zarządzanie stronami w systemie plików'],
            'files' => $contentFiles,
            'dir' => self::DIR_CONTENT,
        ]);
    }

    /**
     * @param Request $request
     * @return ResponseInterface
     *
     * @Route("[panel]/create-edit-page")
     */
    public function createOrEditPage(Request $request): ResponseInterface
    {
        $file = $request->getQuery('file');
        $isPost = $request->isMethod('POST');
        $formData = $isPost ? $this->service->getPageFormData($request) : [];

        // Przygotowanie danych
        $meta = $this->service->prepareMetaPage($file);
        $page = $this->service->preparePagePage($file);
        $pageData = $file ? $this->service->getFileFields($file) : null;
        $fields = $this->service->prepareFieldsPage($pageData ?? $formData) ?: null;
        $dirImages = $this->filesystem->scanDirectory(self::DIR_IMG_PAGE);

        // Obsługa POST: Tworzenie lub edycja
        if ($isPost) {
            $validateErrors = $this->form->validatePageForm($formData);

            if (empty($validateErrors)) {
                if ($file) {
                    try {
                        $result = $this->service->editPage(
                            $file,
                            $formData['form_keywords'],
                            $formData['form_description'],
                            $formData['form_title'],
                            $formData['form_content']
                        );

                        $this->setFlash('messageSuccess', 'Strona została pomyślnie edytowana.');
                        $this->redirect('./' . getenv('APP_PANEL') . '/create-edit-page', ['file' => $file]);
                    } catch (RuntimeException $e) {
                        $this->setFlash('messageDanger', 'Nie udało się edytować strony: ' . $e->getMessage());
                    }
                } else {
                    $result = $this->service->createPage(
                        $formData['form_filename'],
                        $formData['form_keywords'],
                        $formData['form_description'],
                        $formData['form_title'],
                        $formData['form_content']
                    );

                    if ($result['status'] === 'success') {
                        $this->setFlash('messageSuccess', $result['message']);
                        $this->redirect('./' . getenv('APP_PANEL') . '/create-edit-page', ['file' => $result['fileName'] ?? $formData['form_filename']]);
                    } else {
                        $this->setFlash('messageDanger', $result['message']);
                    }
                }
            } else {
                $fields = $this->service->prepareFieldsPage($formData) ?: null;
            }
        }

        return $this->render('panel/create_edit_page.phtml', [
            'meta' => $meta,
            'page' => $page,
            'fields' => $fields,
            'images' => $dirImages,
            'validate' => $validateErrors ?? null,
        ]);
    }

    /**
     * @param Request $request
     * @return Response
     *
     * @Route("/ajax-delete-page")
     */
    public function ajaxDeletePage(Request $request): Response
    {
        try {
            if (!$request->isMethod('POST')) {
                return Response::json(['success' => false, 'message' => "Niedozwolona metoda HTTP."], 405);
            }

            $filename = $request->getPost('file');
            if (!$filename) {
                return Response::json(['success' => false, 'message' => "Nie podano nazwy pliku."], 400);
            }

            // Zabezpieczenie przed manipulacją ścieżką
            $filename = basename($filename);
            $pathFile = self::DIR_CONTENT . $filename;

            // Sprawdź, czy plik istnieje
            if (!file_exists($pathFile)) {
                return Response::json(['success' => false, 'message' => "Nazwa pliku jest nieprawidłowa lub plik nie istnieje."], 404);
            }

            // Usuń plik
            if ($this->filesystem->fileMultiDelete($pathFile) === null) {
                $message = "Plik został usunięty pomyślnie!";
                $this->setFlash('messageSuccess', $message);
                return Response::json(['success' => true, 'message' => $message], 200);
            } else {
                return Response::json(['success' => false, 'message' => "Nie udało się usunąć pliku. Spróbuj ponownie."], 500);
            }
        } catch (Exception $exception) {
            $this->logger->critical($exception->getMessage(), ['exception' => $exception]);
            return Response::json(['success' => false, 'message' => "Wystąpił błąd serwera: " . $exception->getMessage()], 500);
        }
    }
}
