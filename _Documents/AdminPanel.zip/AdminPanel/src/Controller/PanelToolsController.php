<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use App\Service\PanelToolsService;
use Dbm\Classes\AdminBaseController;
use Dbm\Classes\Http\Request;
use Dbm\Interfaces\DatabaseInterface;
use Lib\Files\FileSystem;
use Psr\Http\Message\ResponseInterface;

class PanelToolsController extends AdminBaseController
{
    private $service;
    private $filesystem;

    public function __construct(DatabaseInterface $database)
    {
        parent::__construct($database);

        $this->service = new PanelToolsService();
        $this->filesystem = new FileSystem();
    }

    /**
     * @param Request $request
     * @return ResponseInterface
     *
     * @Route("[panel]/error-log")
     */
    public function errorLog(Request $request): ResponseInterface
    {
        $type = $request->getQuery('type');
        $action = $request->getQuery('action');
        $file = $request->getQuery('file');
        $fileDir = $this->service->toolsPath($type);
        $filePath = $fileDir . $file;

        if ($action == 'delete') {
            $this->filesystem->deleteFile($filePath);
            $file = null;
        }

        list($title, $link) = $this->service->getTitleAndLink($type);

        $contentFiles = $this->filesystem->scanDirectory($fileDir, 1, ['..', '.', 'mailer', 'logger']);
        $contentPreview = $this->filesystem->contentPreview($filePath);

        return $this->render('panel/error_log.phtml', [
            'meta' => ['meta.title' => $title],
            'files' => $contentFiles,
            'preview' => $contentPreview,
            'title' => $title,
            'link' => $link,
            'type' => $type,
            'item' => $file,
        ]);
    }
}
