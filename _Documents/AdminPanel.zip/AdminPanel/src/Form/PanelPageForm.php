<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Form;

class PanelPageForm
{
    public function validatePageForm(array $formData): array
    {
        $errors = [];

        if (isset($formData['form_filename'])) {
            if (empty($formData['form_filename'])) {
                $errors['errorFilename'] = "Pole nazwa pliku jest wymagane!";
            } elseif (!preg_match("/^[a-z\-]+$/", $formData['form_filename'])) {
                $errors['errorFilename'] = "Nazwa pliku może zawierać tylko małe litery (a-z) i myślnik (-).";
            }
        }

        if (empty($formData['form_keywords'])) {
            $errors['errorKeywords'] = "Pole słowa kluczowe jest wymagane!";
        }

        if (empty($formData['form_description'])) {
            $errors['errorDescription'] = "Pole opisu jest wymagane!";
        }

        if (empty($formData['form_title'])) {
            $errors['errorTitle'] = "Pole tytułu jest wymagane!";
        } elseif ((mb_strlen($formData['form_title']) < 3) || (mb_strlen($formData['form_title']) > 65)) {
            $errors['errorTitle'] = "Tytuł musi zawierać od 3 do 65 znaków!";
        }

        if (empty($formData['form_content'])) {
            $errors['errorContent'] = "Pole zawartość jest wymagane!";
        } elseif (mb_strlen($formData['form_content']) < 1000) {
            $errors['errorContent'] = "Zawartość musi zawierać minimum 1000 znaków!";
        }

        return $errors;
    }
}
