<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Service;

use Dbm\Classes\Logs\Logger;
use Lib\Files\FileSystem;
use RuntimeException;

class PanelPageService
{
    private const DIR_CONTENT = BASE_DIRECTORY . 'data/content/';
    private const SPLIT = "<!--@-->";
    private $filesystem;
    private $logger;

    public function __construct(FileSystem $filesystem, Logger $logger)
    {
        $this->filesystem = $filesystem;
        $this->logger = $logger;
    }

    public function getFileFields(string $file): ?array
    {
        $filePath = self::DIR_CONTENT . $file;

        if (file_exists($filePath)) {
            $fileContent = file_get_contents($filePath);
            $fileFields = explode(self::SPLIT, $fileContent);

            return [
                'filename' => basename($file, '.txt'),
                'keywords' => trim($fileFields[0]),
                'description' => trim($fileFields[1]),
                'title' => trim($fileFields[2]),
                'content' => trim($fileFields[3]),
            ];
        }

        return null;
    }

    public function prepareMetaPage(?string $file): array
    {
        if (!empty($file)) {
            $meta = [
                'meta.title' => "Edytuj stronę internetową",
            ];
        } else {
            $meta = [
                'meta.title' => "Dodaj stronę internetową",
            ];
        }

        return $meta;
    }

    public function preparePagePage(?string $file): array
    {
        if (!empty($file)) {
            $page = [
                'submit' => '<i class="bi bi-pencil-square me-2"></i>Edytuj',
                'file' => trim($file),
                'accordion' => false,
            ];
        } else {
            $page = [
                'submit' => '<i class="bi bi-plus-circle me-2"></i>Dodaj',
                'file' => null,
                'accordion' => true,
            ];
        }

        return $page;
    }

    public function prepareFieldsPage(array $data): array
    {
        return [
            'filename' => $data['form_filename'] ?? $data['filename'] ?? null,
            'keywords' => $data['form_keywords'] ?? $data['keywords'] ?? null,
            'description' => $data['form_description'] ?? $data['description'] ?? null,
            'title' => $data['form_title'] ?? $data['title'] ?? null,
            'content' => $data['form_content'] ?? $data['content'] ?? null,
        ];
    }


    public function getPageFormData(object $request): array
    {
        return [
            //'form_id' => (int) $request->getQuery('id'),
            'form_filename' => $request->getPost('form_filename'),
            'form_keywords' => $request->getPost('form_keywords'),
            'form_description' => $request->getPost('form_description'),
            'form_title' => $request->getPost('form_title'),
            'form_content' => $request->getPost('form_content'),
        ];
    }

    public function createPage(string $fileName, string $keywords, string $description, string $title, string $content): array
    {
        $filePath = self::DIR_CONTENT . $fileName . '.txt';

        if (file_exists($filePath)) {
            return [
                'status' => 'danger',
                'message' => 'Plik o podanej nazwie już istnieje.',
            ];
        }

        $fileContent = implode("\n" . self::SPLIT . "\n", [$keywords, $description, $title, $content]);

        try {
            $this->filesystem->saveFile($filePath, $fileContent);

            return [
                'status' => 'success',
                'message' => 'Nowa strona została pomyślnie utworzona.',
                'fileName' => $fileName . '.txt',
            ];
        } catch (RuntimeException $e) {
            return [
                'status' => 'danger',
                'message' => 'Nie udało się utworzyć strony: ' . $e->getMessage(),
            ];
        }
    }

    public function editPage(string $file, string $keywords, string $description, string $title, string $content): bool
    {
        $filePath = self::DIR_CONTENT . $file;
        $fileContent = implode("\n" . self::SPLIT . "\n", [$keywords, $description, $title, $content]);

        try {
            $this->filesystem->editFile($filePath, $fileContent);
            return true;
        } catch (RuntimeException $e) {
            $this->logger->critical('Error method editPage(): ' . $e->getMessage());
            return false;
        }
    }
}
