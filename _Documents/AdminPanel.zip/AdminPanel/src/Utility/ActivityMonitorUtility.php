<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Utility;

class ActivityMonitorUtility
{
    private const DIR_DATA = BASE_DIRECTORY . 'data' . DS . 'json' . DS;
    private const LOG_FILE = 'activity_monitor.json';
    private const EXPIRATION_TIME = 604800; // 7 dni w sekundach

    private string $logFilePath;

    public function __construct()
    {
        // Upewnij się, że katalog danych istnieje
        if (!is_dir(self::DIR_DATA)) {
            mkdir(self::DIR_DATA, 0777, true);
        }

        $this->logFilePath = self::DIR_DATA . self::LOG_FILE;

        // Upewnij się, że plik logu istnieje
        if (!file_exists($this->logFilePath)) {
            file_put_contents($this->logFilePath, json_encode([])); // Tworzy pustą tablicę JSON
        }
    }

    /**
     * Rejestruje aktywność użytkownika lub gościa na stronie.
     */
    public function logActivity(string $title, ?string $user = null): void
    {
        $timestamp = time();
        $data = [
            'title' => $title,
            'user' => $user ?? 'Guest',
            'visit' => 1,
            'timestamp' => $timestamp,
        ];

        // Pobierz istniejące dane
        $currentData = $this->getAllActivities();
        $updated = false;

        // Zaktualizuj istniejący wpis, jeśli istnieje
        foreach ($currentData as &$activity) {
            if ($activity['title'] === $title && $activity['user'] === $data['user']) {
                // Aktualizacja
                $activity['visit'] = (int) $activity['visit'] + 1;
                $activity['timestamp'] = $timestamp;
                $updated = true;
                break;
            }
        }

        // Dodaj nowe dane, jeśli nie znaleziono wpisu do aktualizacji
        if (!$updated) {
            $currentData[] = $data;
        }

        // Zapisz dane z powrotem do pliku
        $this->saveToFile($currentData);
        $this->cleanOldActivities();
    }

    /**
     * Pobiera wszystkie zapisane aktywności.
     */
    public function getAllActivities(): array
    {
        $currentData = json_decode(file_get_contents($this->logFilePath), true);

        return is_array($currentData) ? $currentData : [];
    }

    /**
     * Formatuje dane dla szablonu, sortuje od najnowszych i ogranicza wynik.
     */
    public function formatActivities(int $limit = 10): array
    {
        $currentData = $this->getAllActivities();
        $now = time();

        // Sortuj od najnowszych na podstawie 'timestamp'
        usort($currentData, function ($a, $b) {
            return $b['timestamp'] <=> $a['timestamp'];
        });

        // Przygotuj sformatowane dane
        $formattedData = [];
        foreach (array_slice($currentData, 0, $limit) as $activity) {
            $timeAgo = $this->timeAgo($now - $activity['timestamp']);
            $formattedData[] = [
                'time' => $timeAgo,
                'title' => $activity['title'],
                'user' => $activity['user'],
                'visit' => $activity['visit'],
            ];
        }

        return $formattedData;
    }

    /**
     * Zapisuje dane do pliku.
     */
    private function saveToFile(array $data): void
    {
        file_put_contents($this->logFilePath, json_encode($data, JSON_PRETTY_PRINT));
    }

    /**
     * Usuwa logi starsze niż określony czas (domyślnie 7 dni).
     */
    private function cleanOldActivities(): void
    {
        $currentData = $this->getAllActivities();
        $now = time();

        // Filtruj dane, usuwając stare wpisy
        $filteredData = array_filter($currentData, function ($activity) use ($now) {
            return ($now - $activity['timestamp']) <= self::EXPIRATION_TIME;
        });

        // Zapisz przefiltrowane dane
        $this->saveToFile($filteredData);
    }

    /**
     * Przekształca różnicę czasu w czytelny format
     */
    private function timeAgo(int $seconds): string
    {
        $periods = [
            60 => 'sek.', // Mniej niż 1 minuta
            3600 => 'min', // Mniej niż 1 godzina
            86400 => 'godz.', // Mniej niż 1 dzień
            604800 => 'dni', // Mniej niż 1 tydzień
        ];

        foreach ($periods as $limit => $label) {
            if ($seconds < $limit) {
                $value = floor($seconds / ($limit / 60));
                return "$value $label";
            }
        }

        // Jeśli przekroczono 1 tydzień
        $weeks = floor($seconds / 604800);
        return "$weeks tydzień" . ($weeks > 1 ? "e" : "");
    }
}
