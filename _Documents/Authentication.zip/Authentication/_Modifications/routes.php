<?php

$installClasses = ['AuthenticationController::class', 'AccountController::class'];

$installUses = <<<PHP
use App\\Controller\\AuthenticationController;
use App\\Controller\\AccountController;
PHP;

$installRoutes = <<<PHP
// Authentication routes
    \$router->addRoute('/login', [AuthenticationController::class, 'login'], 'login');
    \$router->addRoute('/login/signin', [AuthenticationController::class, 'loginSignin'], 'login_signin');
    \$router->addRoute('/login/logout', [AuthenticationController::class, 'loginLogout'], 'login_logout');
    \$router->addRoute('/register', [AuthenticationController::class, 'register'], 'register');
    \$router->addRoute('/register/signup', [AuthenticationController::class, 'registerSignup'], 'register_signup');
    \$router->addRoute('/register/verified', [AuthenticationController::class, 'registerVerified'], 'register_verified');
    \$router->addRoute('/reset', [AuthenticationController::class, 'reset'], 'reset');
    \$router->addRoute('/reset/pass', [AuthenticationController::class, 'resetPass'], 'reset_pass');
    \$router->addRoute('/reset/password', [AuthenticationController::class, 'resetPassword'], 'reset_password');
    // Account routes
    \$router->addRoute('/account', [AccountController::class, 'index'], 'account');
    \$router->addRoute('/account/profile', [AccountController::class, 'accountProfile'], 'account_profile');
    \$router->addRoute('/account/password', [AccountController::class, 'accountPassword'], 'account_password');
PHP;

$installValues = '';
