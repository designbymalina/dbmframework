<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use App\Form\AccountForm;
use App\Model\AccountModel;
use App\Service\AccountService;
use Dbm\Classes\BaseController;
use Dbm\Classes\Exceptions\UnauthorizedRedirectException;
use Dbm\Classes\Http\Request;
use Dbm\Interfaces\DatabaseInterface;
use Psr\Http\Message\ResponseInterface;

class AccountController extends BaseController
{
    private AccountModel $model;
    private AccountService $service;
    private AccountForm $form;

    public function __construct(DatabaseInterface $database)
    {
        parent::__construct($database);

        if (empty($this->getSession(getenv('APP_SESSION_KEY')))) {
            throw new UnauthorizedRedirectException('./');
        }

        $this->model = new AccountModel($database);
        $this->service = new AccountService($this->model);
        $this->form = new AccountForm();
    }

    /**
     * @return ResponseInterface
     *
     * @Route: "/account"
     */
    public function index(): ResponseInterface
    {
        // INFO: Access is checked in the constructor (and Router), here it is an additional security measure.
        if (!$this->getSession(getenv('APP_SESSION_KEY'))) {
            return $this->redirect("./");
        }

        $userId = (int) $this->getSession(getenv('APP_SESSION_KEY'));

        if ($userId <= 0) {
            return $this->redirect("./login");
        }

        $userAccount = $this->model->userAccount($userId);

        return $this->render('account/index.phtml', [
            'meta' => ['meta.title' => $this->translation->trans('account.title') . ' - ' . getenv('APP_NAME')],
            'user' => $userAccount,
        ]);
    }

    /**
     * @param Request $request
     * @return ResponseInterface
     *
     * @Route: "/account/profile"
     */
    public function accountProfile(Request $request): ResponseInterface
    {
        $id = (int) $this->getSession(getenv('APP_SESSION_KEY'));
        $userAccount = $this->model->userAccount($id);

        if ($request->isMethod('POST')) {
            $formData = $this->service->filterFormData($request->getParsedBody());
            $avatarUploadResult = $this->service->processAvatarUpload($request);

            $validateError = [];

            if (is_array($avatarUploadResult) && ($avatarUploadResult['status'] ?? '') === 'success') {
                $formData['file_avatar'] = $avatarUploadResult['data'];
            } elseif (!empty($avatarUploadResult['message'])) {
                $validateError['error_avatar'] = $avatarUploadResult['message'];
            }

            $validateError += $this->form->validateProfileForm($formData);

            if (empty($validateError)) {
                if ($this->service->makeUpdateUserProfile($id, $formData, $userAccount)) {
                    if (!empty($formData['file_avatar'])) {
                        $this->service->deleteOldAvatar($userAccount->avatar, $formData['file_avatar'] ?? null);
                    }

                    $this->setFlash('messageSuccess', 'Profil został pomyślnie edytowany.');
                } else {
                    $this->setFlash('messageDanger', 'Wystąpił nieoczekiwany błąd podczas edycji profilu!');
                }
                return $this->redirect("./account");
            }

            $formData += $validateError;
        }

        return $this->render('account/profile.phtml', [
            'meta' => ['meta.title' => 'Edycja profilu użytkownika'],
            'user' => $userAccount,
            'form' => $formData ?? null,
        ]);
    }

    /**
     * @param Request $request
     * @return ResponseInterface
     *
     * @Route: "/account/password"
     */
    public function accountPassword(Request $request): ResponseInterface
    {
        $id = (int) $this->getSession(getenv('APP_SESSION_KEY'));
        $userAccount = $this->model->userAccount($id);

        if ($request->isMethod('POST')) {
            $formData = $this->service->filterFormData($request->getParsedBody());
            $validateError = $this->service->makeValidatePassword($id, $formData);

            if (empty($validateError)) {
                if ($this->service->makeUpdatePassword($id, $formData['dbm_password'])) {
                    $this->setFlash('messageSuccess', 'Hasło zostało pomyślnie zmienione.');
                } else {
                    $this->setFlash('messageDanger', 'Wystąpił nieoczekiwany błąd podczas zmiany hasła!');
                }

                return $this->redirect("./account");
            }

            $formData = array_merge($formData, $validateError);
        }

        return $this->render('account/password.phtml', [
            'meta' => ['meta.title' => 'Zmiana hasła'],
            'user' => $userAccount,
            'form' => $formData ?? null,
        ]);
    }
}
