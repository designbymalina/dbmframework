<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use App\Form\AuthenticationForm;
use App\Model\AuthenticationModel;
use App\Service\AuthenticationService;
use Dbm\Classes\BaseController;
use Dbm\Classes\Http\Request;
use Dbm\Classes\Logs\Logger;
use Dbm\Classes\RememberMe;
use Dbm\Interfaces\DatabaseInterface;
use Psr\Http\Message\ResponseInterface;

class AuthenticationController extends BaseController
{
    private AuthenticationModel $model;
    private AuthenticationForm $form;
    private AuthenticationService $service;
    private RememberMe $remember;
    private Logger $logger;

    public function __construct(DatabaseInterface $database)
    {
        parent::__construct($database);

        $this->model = new AuthenticationModel($database, $this->translation);
        $this->form = new AuthenticationForm($this->model, $this->translation);
        $this->service = new AuthenticationService($this->model, $this->translation);
        $this->remember = new RememberMe($database, $this);
        $this->logger = new Logger();
    }

    /**
     * Logowanie użytkownika
     *
     * @return ResponseInterface
     *
     * @Route: "/login"
     */
    public function login(): ResponseInterface
    {
        if ($this->getSession(getenv('APP_SESSION_KEY'))) {
            return $this->redirect("./account");
        }

        return $this->render('authentication/login.phtml', [
            'meta' => $this->service->getMetaLogin(),
        ]);
    }

    /**
     * Obsługa logowania użytkownika
     *
     * @param Request $request
     * @return ResponseInterface
     *
     * @Route: "/login/signin"
     */
    public function loginSignin(Request $request): ResponseInterface
    {
        if (!$request->isMethod('POST')) {
            return $this->redirect('./login');
        }

        $formData = $this->service->filterFormData($request->getParsedBody());

        if (!$this->isValidCsrf($formData)) {
            $this->setFlash("messageDanger", $this->translation->trans('alert.invalid_csrf_token'));
            return $this->redirect('./login');
        }

        $this->unsetSession('csrf_token');

        $validationResult = $this->form->validateLoginForm($formData);

        if ($validationResult['status'] === 'success') {
            if (!empty($formData['dbm_remember_me']) && is_string($formData['dbm_remember_me'])) {
                $this->remember->createRememberMe((int) $validationResult['user_id']);
            }

            if (!session_regenerate_id(true)) {
                $this->logger->error("Failed to regenerate session ID in loginSignin()!");
                $this->setFlash("messageDanger", $this->translation->trans('alert.unexpected_error'));
                return $this->redirect("./login");
            }

            $this->setSession(getenv('APP_SESSION_KEY'), $validationResult['user_id']);
            $this->setFlash("messageSuccess", $this->translation->trans('authn.login.alert.logged_in_system'));
            return $this->redirect("./account");
        }

        $this->setFlash("messageWarning", $validationResult['message']);

        return $this->render('authentication/login.phtml', [
            'meta' => $this->service->getMetaLogin(),
            'fields' => $formData,
            'validate' => null,
        ]);
    }

    /**
     * Wylogowanie użytkownika
     *
     * @return ResponseInterface
     *
     * @Route: "/login/logout"
     */
    public function loginLogout(): ResponseInterface
    {
        if ($this->remember->checkRememberMe()) {
            $this->remember->removeRememberMe();
        }

        $this->destroySession();
        $this->setFlash("messageSuccess", $this->translation->trans('authn.login.alert.logged_out_system'));
        return $this->redirect('./');
    }

    /**
     * Rejestracja użytkownika
     *
     * @return ResponseInterface
     *
     * @Route: "/register"
     */
    public function register(): ResponseInterface
    {
        if ($this->getSession(getenv('APP_SESSION_KEY'))) {
            return $this->redirect("./account");
        }

        return $this->render('authentication/register.phtml', [
            'meta' => $this->service->getMetaRegister(),
        ]);
    }

    /**
     * Obsługa rejestracji użytkownika
     *
     * @param Request $request
     * @return ResponseInterface
     *
     * @Route: "/register/signup"
     */
    public function registerSignup(Request $request): ResponseInterface
    {
        if (!$request->isMethod('POST')) {
            return $this->redirect('./register');
        }

        $formData = $this->service->filterFormData($request->getParsedBody());

        if (!$this->isValidCsrf($formData)) {
            $this->setFlash("messageDanger", $this->translation->trans('alert.invalid_csrf_token'));
            return $this->redirect('./login');
        }

        $this->unsetSession('csrf_token');

        $validateError = $this->form->validateRegisterForm($formData);

        if (!$validateError) {
            $success = $this->service->makeInsertCreateAccount($formData);
            $redirectPath = $success ? "./login" : "./register";
            $messageType = $success ? "messageSuccess" : "messageDanger";
            $messageKey = $success
                ? 'authn.register.alert.account_created'
                : 'alert.unexpected_error_try_again';

            $this->setFlash($messageType, $this->translation->trans($messageKey));

            return $this->redirect($redirectPath);
        }

        return $this->render('authentication/register.phtml', [
            'meta' => $this->service->getMetaRegister(),
            'fields' => $formData,
            'validate' => $validateError,
        ]);
    }

    /**
     * Weryfikacja konta użytkownika
     *
     * @param Request $request
     * @return ResponseInterface
     *
     * @Route: "/register/verified?token={token}"
     */
    public function registerVerified(Request $request): ResponseInterface
    {
        $token = trim($request->getQuery('token') ?? '');

        if (empty($token)) { // INFO: or if (!preg_match('/^[a-f0-9]{40}$/i', $token))
            $this->setFlash("messageDanger", $this->translation->trans('authn.register.alert.no_token'));
            return $this->redirect("./login");
        }

        if (!$this->model->isTokenValid($token)) {
            $this->setFlash("messageWarning", $this->translation->trans('authn.register.alert.token_expired'));
            return $this->redirect("./login");
        }

        $updated = $this->model->verifyUser($token);

        $this->setFlash(
            $updated ? "messageSuccess" : "messageDanger",
            $this->translation->trans($updated
                ? 'authn.register.alert.account_verified'
                : 'alert.unexpected_error')
        );

        return $this->redirect("./login");
    }

    /**
     * Resetowanie hasła
     *
     * @return ResponseInterface
     *
     * @Route: "/reset"
     */
    public function reset(): ResponseInterface
    {
        if ($this->getSession(getenv('APP_SESSION_KEY'))) {
            return $this->redirect("./account");
        }

        return $this->render('authentication/reset.phtml', [
            'meta' => $this->service->getMetaReset(),
        ]);
    }

    /**
     * Resetowanie hasła
     *
     * @param Request $request
     * @return ResponseInterface
     *
     * @Route: "/reset/pass"
     */
    public function resetPass(Request $request): ResponseInterface
    {
        if (!$request->isMethod('POST')) {
            return $this->redirect('./reset');
        }

        $formData = $this->service->filterFormData($request->getParsedBody());

        if (!$this->isValidCsrf($formData)) {
            $this->setFlash("messageDanger", $this->translation->trans('alert.invalid_csrf_token'));
            return $this->redirect('./login');
        }

        $this->unsetSession('csrf_token');

        $validateError = $this->form->validateResetForm($formData['dbm_email']);

        if (empty($validateError)) {
            $this->model->deleteResetPassword();
            $resetPassword = $this->service->makeInsertResetPassword($formData['dbm_email']);

            if ($resetPassword) {
                $this->setFlash("messageSuccess", $this->translation->trans('authn.reset.alert.send_reset_password'));
                return $this->redirect("./login");
            } else {
                $this->setFlash("messageDanger", $this->translation->trans('alert.unexpected_error_try_again'));
                return $this->redirect("./reset");
            }
        } elseif (!empty($validateError['error_no_email'])) {
            $this->setFlash("messageSuccess", $this->translation->trans('authn.reset.alert.send_reset_password'));
            return $this->redirect("./login");
        } else {
            return $this->render('authentication/reset.phtml', [
                'meta' => $this->service->getMetaReset(),
                'fields' => $formData,
                'validate' => $validateError,
            ]);
        }
    }

    /**
     * Resetowanie hasła
     *
     * @param Request $request
     * @return ResponseInterface
     *
     * @Route: "/reset/password?token={token}"
     */
    public function resetPassword(Request $request): ResponseInterface
    {
        $token = $request->get('token');

        // Part of the method for the GET action
        if ($token) {
            $dataReset = $this->model->getResetPassword(['token' => $token]);

            if ($token && (!$dataReset || $this->service->isTokenExpired($dataReset))) {
                $this->setFlash("messageWarning", $this->translation->trans('authn.reset.alert.token_expires'));
                return $this->redirect("./reset");
            }
        }

        // Part of the method for the POST action
        if ($request->isPost()) {
            $formData = $this->service->filterFormData($request->getParsedBody());

            if (!$this->isValidCsrf($formData)) {
                $this->setFlash("messageDanger", $this->translation->trans('alert.invalid_csrf_token'));
                return $this->redirect('./login');
            }

            $this->unsetSession('csrf_token');

            $validateError = $this->form->validateResetPasswordForm($formData);

            if (isset($dataReset) && empty($validateError)) {
                $isUpdated = $this->service->makeUpdateUserPassword($dataReset->email, $formData['dbm_password']);

                if ($isUpdated) {
                    $this->setFlash('messageSuccess', $this->translation->trans('authn.reset.alert.updated_success'));
                    return $this->redirect("./login");
                } else {
                    $this->setFlash('messageDanger', $this->translation->trans('alert.unexpected_error_try_again'));
                    return $this->redirect("./reset");
                }
            } else {
                $this->setFlash('messageDanger', $this->translation->trans('authn.reset.alert.validation_error'));
            }
        }

        return $this->render('authentication/reset_password.phtml', [
            'meta' => $this->service->getMetaReset(),
            'fields' => $formData ?? null,
            'validate' => $validateError ?? null,
            'token' => $token,
        ]);
    }

    private function isValidCsrf($formData): bool
    {
        $postedCsrfToken = $formData['csrf_token'] ?? null;

        if (!$this->form->validateCsrfToken($this->getSession('csrf_token'), $postedCsrfToken)) {
            $this->unsetSession('csrf_token');
            return false;
        }
        return true;
    }
}
