<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Form;

class AccountForm
{
    public function validatePasswordForm(array $formData, object $userData): array
    {
        $errors = [];

        if (empty($formData['dbm_password_old'])) {
            $errors['error_password_old'] = 'Aktualne hasło jest wymagane!';
        } elseif (!password_verify($formData['dbm_password_old'], $userData->password)) {
            $errors['error_password_old'] = 'Podano nieprawidłowe aktualne hasło!';
        }

        if (empty($formData['dbm_password'])) {
            $errors['error_password'] = 'Hasło jest wymagane!';
        } elseif (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,30}$/", $formData['dbm_password'])) {
            $errors['error_password'] = 'Hasło musi zawierać co najmniej jedną małą i wielką literę, cyfrę, znak specjalny oraz mieć od 6 do 30 znaków.';
        }

        if (empty($formData['dbm_password_repeat'])) {
            $errors['error_password_repeat'] = 'Wymagane jest potwierdzenie hasła!';
        } elseif ($formData['dbm_password'] !== $formData['dbm_password_repeat']) {
            $errors['error_password_repeat'] = 'Hasło i jego potwtórzenie są różne!';
        }

        return $errors;
    }

    public function validateProfileForm(array $formData): array
    {
        $errors = [];

        if (!empty($formData['dbm_fullname']) && !preg_match('/^[\pL \'-]*$/u', $formData['dbm_fullname'])) {
            $errors['error_fullname'] = 'Proszę wprowadzić poprawnie imię i nazwisko.';
        }

        if (!empty($formData['dbm_phone']) && !preg_match('/^(\d{3}\s?\d{3}\s?\d{3}|\+?\d{2}\s?\d{3}\s?\d{3}\s?\d{3})$/', $formData['dbm_phone'])) {
            $errors['error_phone'] = 'Proszę wprowadzić poprawny numer telefonu: 9-cyfrowy lub 12-znakowy numer w formacie międzynarodowym.';
        }

        if (!empty($formData['dbm_website']) && filter_var($formData['dbm_website'], FILTER_VALIDATE_URL)) {
            $errors['error_website'] = 'Proszę wprowadzić poprawny adres strony internetowej.';
        }

        if (!empty($formData['dbm_profession']) && !preg_match('/^[\pL \'-]*$/u', $formData['dbm_profession'])) {
            $errors['error_profession'] = 'Proszę wprowadzić poprawnie profesje.';
        }

        return $errors;
    }
}
