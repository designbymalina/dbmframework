<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Form;

use App\Model\AuthenticationModel;
use Dbm\Interfaces\TranslationInterface;

class AuthenticationForm
{
    private const VALIDATION_LOGIN = 'loginNotFound';
    private const VALIDATION_PASSWORD = 'passwordNotMatched';

    private $translation;
    private $model;

    public function __construct(AuthenticationModel $model, TranslationInterface $translation)
    {
        $this->translation = $translation;
        $this->model = $model;
    }

    public function validateCsrfToken(string $sessionToken, ?string $formToken): ?bool
    {
        if (is_string($formToken)) {
            return hash_equals($sessionToken, $formToken);
        }

        return null;
    }

    public function validateRegisterForm(array $formData): array
    {
        $errors = [];

        if (empty($formData['dbm_login'])) {
            $errors['error_login'] = $this->translation->trans('authn.register.alert.login_required');
        } elseif (!preg_match("/^[a-z\d_]{2,30}$/i", $formData['dbm_login'])) {
            $errors['error_login'] = $this->translation->trans('authn.register.alert.login_pattern');
        } elseif ($this->model->checkLogin($formData['dbm_login'])) {
            $errors['error_login'] = $this->translation->trans('authn.register.alert.login_exist');
        }

        if (empty($formData['dbm_email'])) {
            $errors['error_email'] = $this->translation->trans('authn.register.alert.email_required');
        } elseif (!filter_var($formData['dbm_email'], FILTER_VALIDATE_EMAIL)) {
            $errors['error_email'] = $this->translation->trans('authn.register.alert.email_filter');
        } elseif ($this->model->checkEmail($formData['dbm_email'])) {
            $errors['error_email'] = $this->translation->trans('authn.register.alert.email_exist');
        }

        if (empty($formData['dbm_password'])) {
            $errors['error_password'] = $this->translation->trans('authn.register.alert.password_required');
        } elseif (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,30}$/", $formData['dbm_password'])) {
            $errors['error_password'] = $this->translation->trans('authn.register.alert.password_pattern');
        }

        if (empty($formData['dbm_confirmation'])) {
            $errors['error_confirmation'] = $this->translation->trans('authn.register.alert.password_confirmation_required');
        } elseif ($formData['dbm_password'] !== $formData['dbm_confirmation']) {
            $errors['error_confirmation'] = $this->translation->trans('authn.register.alert.password_confirmation_different');
        }

        return $errors;
    }

    public function validateLoginForm(array $formData): array
    {
        if (empty($formData['dbm_login']) || empty($formData['dbm_password'])) {
            return [
                'status' => 'error',
                'message' => $this->translation->trans('authn.login.alert.incorrect_login_details')
            ];
        }

        $queryParams = [':login' => $formData['dbm_login'], ':email' => $formData['dbm_login']];
        $correctUser = $this->model->checkIsUserCorrect($queryParams, $formData['dbm_password']);

        if (empty($correctUser) || in_array($correctUser, [self::VALIDATION_LOGIN, self::VALIDATION_PASSWORD], true)) {
            return [
                'status' => 'error',
                'message' => $this->translation->trans('authn.login.alert.incorrect_login_details')
            ];
        }

        return [
            'status' => 'success',
            'user_id' => trim($correctUser)
        ];
    }

    public function validateResetForm(string $email): array
    {
        $errors = [];

        if (empty($email)) {
            $errors['error_email'] = $this->translation->trans('authn.register.alert.email_required');
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['error_email'] = $this->translation->trans('authn.register.alert.email_filter');
        } elseif (!$this->model->checkEmail($email)) {
            $errors['error_no_email'] = $this->translation->trans('authn.reset.alert.email_not_exist');
        }

        return $errors;
    }

    public function validateResetPasswordForm(array $formData): array
    {
        $errors = [];

        if (empty($formData['dbm_password'])) {
            $errors['error_password'] = $this->translation->trans('authn.register.alert.password_required');
        } elseif (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,30}$/", $formData['dbm_password'])) {
            $errors['error_password'] = $this->translation->trans('authn.register.alert.password_pattern');
        }

        if (empty($formData['dbm_password_repeat'])) {
            $errors['error_password_repeat'] = $this->translation->trans('authn.register.alert.password_confirmation_required');
        } elseif ($formData['dbm_password'] !== $formData['dbm_password_repeat']) {
            $errors['error_password_repeat'] = $this->translation->trans('authn.register.alert.password_confirmation_different');
        }

        return $errors;
    }
}
