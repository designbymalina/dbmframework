<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Model;

use Dbm\Interfaces\DatabaseInterface;

class AccountModel
{
    private $database;

    public function __construct(DatabaseInterface $database)
    {
        $this->database = $database;
    }

    public function userAccount(int $id): ?object
    {
        $query = "SELECT details.*, user.id, user.login, user.email, user.created_at
                FROM dbm_user_details details
                JOIN dbm_user user ON details.user_id = user.id
                WHERE user.id = :id";

        $this->database->queryExecute($query, [':id' => $id]);
        return $this->database->fetchObject() ?: null;
    }

    public function getUser(int $id): ?object
    {
        $query = "SELECT * FROM dbm_user WHERE id = :id";

        $this->database->queryExecute($query, [':id' => $id]);
        return $this->database->fetchObject() ?: null;
    }

    public function updatePassword(array $data): bool
    {
        $query = "UPDATE dbm_user SET password = :password WHERE id = :id";

        return $this->database->queryExecute($query, $data);
    }

    public function updateUserDetails(array $data): bool
    {
        if (empty($data['id'])) {
            return false;
        }

        $userId = $data['id'];
        unset($data['id']);

        [$filteredQuery, $filteredParams] = $this->database->buildUpdateQuery($data, 'dbm_user_details', 'user_id=:user_id');

        $filteredParams['user_id'] = $userId;

        return $this->database->queryExecute($filteredQuery, $filteredParams);
    }
}
