<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Service;

use App\Form\AccountForm;
use App\Model\AccountModel;
use Dbm\Classes\Http\Request;
use Lib\Upload\UploadImage;

class AccountService
{
    private const DIR_AVATAR = 'images/avatar/';
    private $model;
    private $form;
    private $upload;

    public function __construct(AccountModel $model)
    {
        $this->model = $model;
        $this->form = new AccountForm();
        $this->upload = new UploadImage();
    }

    public function filterFormData(array $formData): array
    {
        return array_map(function ($value) {
            return is_string($value) ? filter_var($value, FILTER_SANITIZE_SPECIAL_CHARS) : $value;
        }, $formData);
    }

    public function makeUpdateUserProfile(int $id, array $formData, object $userAccount): bool
    {
        $sqlUpdateDetails = [
            'id' => $id,
            'fullname' => $formData['dbm_fullname'],
            'phone' => $formData['dbm_phone'],
            'website' => $formData['dbm_website'],
            'profession' => $formData['dbm_profession'],
            'business' => $formData['dbm_business'],
            'address' => $formData['dbm_address'],
            'biography' => $formData['dbm_biography'],
        ];

        if (!empty($formData['file_avatar'])) {
            $sqlUpdateDetails['avatar'] = $formData['file_avatar'];
        }

        $updateResult = $this->model->updateUserDetails($sqlUpdateDetails);

        return $updateResult;
    }

    public function makeValidatePassword(int $id, array $formData): array
    {
        $userData = $this->model->getUser($id);

        return $this->form->validatePasswordForm($formData, $userData);
    }

    public function makeUpdatePassword(int $id, string $newPassword): bool
    {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $sqlUpdate = [':password' => $hashedPassword, ':id' => $id];

        return $this->model->updatePassword($sqlUpdate);
    }

    public function processAvatarUpload(Request $request): ?array
    {
        $uploadedFile = $request->getUploadedFile('dbm_avatar');

        if (!$uploadedFile || empty($uploadedFile['name'])) {
            return null;
        }

        $this->upload->setTargetDir(self::DIR_AVATAR);
        $this->upload->setAllowedTypes(['jpg', 'png', 'webp']);
        $this->upload->setMaxFileSize(1048576);
        $this->upload->setMaxWidth(520);
        $this->upload->setMaxHeight(520);

        $result = $this->upload->uploadImage($uploadedFile);

        return $result;
    }

    public function deleteOldAvatar(?string $oldAvatar, string $newAvatar): void
    {
        if ($oldAvatar && $oldAvatar !== $newAvatar) {
            $filePath = self::DIR_AVATAR . $oldAvatar;

            if (is_file($filePath) && file_exists($filePath)) {
                unlink($filePath);
            }
        }
    }
}
