<?php

$installConstants = <<<PHP
        //-KEY_CONSTANTS_CMSLITE
        public const FILEPATH_CONFIG_HEADER_NAVIGATION = BASE_DIRECTORY . 'config' . DS . 'header_navigation.json';
        public const FILEPATH_CONFIG_FOOTER_NAVIGATION = BASE_DIRECTORY . 'config' . DS . 'footer_navigation.json';
    PHP;
