<?php

$installClasses = ['CMSLiteController::class'];

$installUses = <<<PHP
use Mod\\CMSLite\\Src\\Controller\\CMSLiteController;
PHP;

$installRoutes = <<<PHP
// CMS Lite index routes
    \$router->addRoute('/ajax-contact', [IndexController::class, 'ajaxContact'], 'ajax_contact');
    \$router->addRoute('/ajax-newsletter', [IndexController::class, 'ajaxNewsletter'], 'ajax_newsletter');
    // CMS Lite page routes
    \$router->addRoute('/page/{slug}', [CMSLiteController::class, 'index'], 'page');
PHP;

$installValues = '';
