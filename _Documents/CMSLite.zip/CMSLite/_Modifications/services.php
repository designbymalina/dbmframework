<?php

$installUses = <<<PHP
use App\\Utility\\NavigationUtility;
PHP;

$installDependencies = <<<PHP
    // CMS Lite Dependencies
    \$container->set(NavigationUtility::class, function () {
        return new NavigationUtility();
    });
PHP;
