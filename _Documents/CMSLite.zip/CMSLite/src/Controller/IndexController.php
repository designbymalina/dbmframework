<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use App\Form\IndexForm;
use App\Service\IndexService;
use App\Utility\InstallerUtility;
use Dbm\Classes\BaseController;
use Dbm\Classes\Http\Request;
use Dbm\Classes\Http\Response;
use Dbm\Classes\Http\Stream;
use Dbm\Classes\Logs\Logger;
use Dbm\Interfaces\DatabaseInterface;
use Psr\Http\Message\ResponseInterface;
use Exception;

class IndexController extends BaseController
{
    private readonly InstallerUtility $installer;
    private readonly IndexForm $indexForm;
    private readonly Logger $logger;

    public function __construct(
        IndexService $indexService,
        ?DatabaseInterface $database = null
    ) {
        parent::__construct($database);

        $this->installer = new InstallerUtility();
        $this->indexForm = new IndexForm();
        $this->logger = new Logger();
    }

    /**
     * @param IndexService $indexService
     * @return ResponseInterface
     *
     * @Route: "/index"
     */
    public function index(IndexService $indexService): ResponseInterface
    {
        /* TODO! $isInstall = $this->installService->isInstallationRemoved();

        if ($isInstall) {
            $this->setFlash('messageInfo', $this->translation->trans('start.alert.application_ready'));
            return $this->redirect('./start');
        } */

        return $this->render('index/index.phtml', [
            'meta' => $indexService->getMetaIndex(),
        ]);
    }

    /**
     * @param IndexService $indexService
     * @return ResponseInterface
     *
     * @Route: "/start"
     */
    public function start(IndexService $indexService): ResponseInterface
    {
        return $this->render('index/start.phtml', [
            'meta' => $indexService->getMetaStart(),
        ]);
    }

    /**
     * @param IndexService $indexService
     * @param Request $request
     * @return ResponseInterface
     *
     * @Route: "/installer"
     */
    public function installer(IndexService $indexService, Request $request): ResponseInterface
    {
        $dirModule = BASE_DIRECTORY . '_Documents' . DS . 'install';
        $pathManifest = BASE_DIRECTORY . '_Documents' . DS . 'install' . DS . 'module.json';

        if (class_exists('\\App\\Controller\\InstallController')) {
            $action = $request->getQuery('action');

            if ($action === 'remove') {
                $msg = $this->installer->uninstallModule($dirModule, $pathManifest);

                if (!empty($msg)) {
                    $alert = $indexService->alertMessage($msg);
                    $this->setFlash($alert['type'], $alert['message']);
                }

                return $this->redirect('./start');
            } else {
                $this->setFlash('messageInfo', $this->translation->trans('install.alert.installer_active'));
            }
        } else {
            $pathZip = BASE_DIRECTORY . '_Documents' . DS . 'install.zip';

            $msg = $this->installer->installModule($dirModule, $pathManifest, $pathZip);

            if (!empty($msg)) {
                $alert = $indexService->alertMessage($msg);
                $this->setFlash($alert['type'], $alert['message']);
            }

            return $this->redirect('./start');
        }

        return $this->render('index/start.phtml', [
            'meta' => $indexService->getMetaInstaller(),
        ]);
    }

    /**
     * @param IndexService $indexService
     * @param Request $request
     * @return ResponseInterface
     *
     * @Route("/ajax-contactr")
     */
    public function ajaxContact(IndexService $indexService, Request $request): ResponseInterface
    {
        try {
            if (!$request->isMethod('POST')) {
                return new Response(405);
            }

            $formData = $indexService->filterFormData($request->getAllPost());
            $csrfToken = $this->getSession('csrf_token');
            $postedCsrfToken = $formData['csrf_token'] ?? null;

            if (!$this->indexForm->validateCsrfToken($csrfToken, $postedCsrfToken)) {
                return new Response(403, [], Stream::create("Invalid CSRF token."));
            }

            $errors = $this->indexForm->validateForm($formData);

            if (!empty($errors)) {
                return new Response(422, [], Stream::create(implode(', ', $errors)));
            }

            $isSent = $indexService->makeContactMessage($formData);

            if ($isSent) {
                return new Response(200, [], Stream::create("OK"));
            } else {
                return new Response(500, [], Stream::create("Failed to send message."));
            }
        } catch (Exception $exception) {
            $this->logger->critical($exception->getMessage(), ['exception' => $exception]);
            return new Response(500);
        }
    }

    /**
     * @param Request $request
     * @return ResponseInterface
     *
     * @Route("/ajax-newsletter")
     */
    public function ajaxNewsletter(Request $request): ResponseInterface
    {
        try {
            if (!$request->isMethod('POST')) {
                return new Response(400);
            }

            // TODO! You can add a newsletter subscription code
            return new Response(200, [], Stream::create("OK"));
        } catch (Exception $exception) {
            $this->logger->critical($exception->getMessage(), ['exception' => $exception]);
            return new Response(500);
        }
    }
}
