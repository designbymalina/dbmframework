<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Form;

class IndexForm
{
    public function validateForm(array $formData): array
    {
        $errors = [];

        if (empty($formData['dbm_name'])) {
            $errors['error_name'] = 'Name is required';
        } elseif (mb_strlen($formData['dbm_name']) < 2 || mb_strlen($formData['dbm_name']) > 60) {
            $errors['error_name'] = 'Name must be between 2 and 60 characters long';
        } elseif (!empty($formData['dbm_name']) && !preg_match('/^[\pL \'-]*$/u', $formData['dbm_name'])) {
            $errors['error_name'] = 'Please enter the name correctly';
        }

        if (empty($formData['dbm_email'])) {
            $errors['error_email'] = 'Email address is required';
        } elseif (!filter_var($formData['dbm_email'], FILTER_VALIDATE_EMAIL)) {
            $errors['error_email'] = 'An invalid email address was provided';
        }

        if (empty($formData['dbm_subject'])) {
            $errors['error_subject'] = 'A message subject is required';
        } elseif (mb_strlen($formData['dbm_subject']) > 120) {
            $errors['error_subject'] = 'The message subject cannot exceed 120 characters';
        }

        if (empty($formData['dbm_message'])) {
            $errors['error_message'] = 'Message content is required';
        } elseif (mb_strlen($formData['dbm_message']) > 2000) {
            $errors['error_message'] = 'The message content cannot exceed 2000 characters';
        }

        return $errors;
    }

    public function validateCsrfToken(?string $sessionToken, ?string $formToken): bool
    {
        return hash_equals($sessionToken ?? '', $formToken ?? '');
    }
}
