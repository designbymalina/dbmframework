<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Service;

use Dbm\Classes\Logs\Logger;
use Dbm\Classes\Translation;
use Lib\Sender\PHPMailerSender;
use Exception;

class IndexService
{
    private Translation $translation;
    private Logger $logger;
    private PHPMailerSender $sender;

    public function __construct()
    {
        $this->translation = new Translation();
        $this->logger = new Logger();
        $this->sender = new PHPMailerSender();
    }

    public function getMetaIndex(): array
    {
        return [
            'meta.title' => $this->translation->trans('index.index_meta_title'),
            'meta.description' => $this->translation->trans('index.index_meta_description'),
            'meta.keywords' => $this->translation->trans('index.index_meta_keywords'),
        ];
    }

    public function getMetaStart(): array
    {
        return [
            'meta.title' => $this->translation->trans('index.start_meta_title'),
            'meta.description' => $this->translation->trans('index.start_meta_description'),
            'meta.keywords' => $this->translation->trans('index.start_meta_keywords'),
            'meta.robots' => "noindex,nofollow",
        ];
    }

    public function getMetaInstaller(): array
    {
        return [
            'meta.title' => $this->translation->trans('index.installer_meta_title'),
            'meta.description' => $this->translation->trans('index.installer_meta_description'),
            'meta.keywords' => $this->translation->trans('index.installer_meta_keywords'),
            'meta.robots' => "noindex,nofollow",
        ];
    }

    public function alertMessage(array $msg): array
    {
        $map = [
            'success' => 'messageSuccess',
            'error' => 'messageDanger',
            'info' => 'messageInfo',
            'warning' => 'messageWarning',
        ];

        $type = $msg['type'] ?? 'info';
        $message = $msg['message'] ?? '';

        $alertType = $map[$type] ?? 'messageInfo';

        return [
            'type' => $alertType,
            'message' => $message,
        ];
    }

    public function filterFormData(array $formData): array
    {
        return array_map(function ($value) {
            return is_string($value) ? htmlspecialchars(stripslashes(trim($value))) : $value;
        }, $formData);
    }

    public function makeContactMessage(array $data): bool
    {
        try {
            if (!$this->sendContactMessage($data)) {
                throw new Exception("An unexpected error occurred! Message could not be sent.");
            }

            return true;
        } catch (Exception $exception) {
            $this->logger->critical($exception->getMessage(), ['exception' => $exception]);
            return false;
        }
    }

    private function sendContactMessage(array $data): bool
    {
        return $this->sender->sendMessage([
            'subject' => $data['dbm_subject'],
            'sender_name' => $data['dbm_name'],
            'sender_email' => $data['dbm_email'],
            'recipient_name' => getenv('MAIL_FROM_NAME'),
            'recipient_email' => getenv('MAIL_FROM_EMAIL'),
            'message_content' => $data['dbm_message'],
        ]);
    }
}
