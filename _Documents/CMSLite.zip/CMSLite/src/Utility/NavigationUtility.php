<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Utility;

use App\Config\ConstantConfig;
use App\Exception\UserNotFoundException;
use Dbm\Classes\Database;
use Dbm\Classes\Logs\Logger;
use Dbm\Classes\Translation;
use Exception;

class NavigationUtility
{
    private Translation $translation;
    private Database $database;
    private Logger $logger;

    public function __construct()
    {
        $this->translation = new Translation();
        $this->database = new Database();
        $this->logger = new Logger();
    }

    // Header Navigation
    public function headerNavigation(): array
    {
        $menuConfig = $this->getHeaderNavigationConfig();
        if (!$menuConfig) {
            return [];
        }

        uasort($menuConfig, fn ($a, $b) => ($a['order'] ?? 999) <=> ($b['order'] ?? 999));

        $currentPage = $_SERVER['REQUEST_URI'] ?? '/';

        return array_map(fn ($config) => $this->buildMenuItem($config, $currentPage), $menuConfig);
    }

    private function buildMenuItem(array $config, string $currentPage): array
    {
        $item = [
            'title'  => $this->translation->trans($config['link']['title']),
            'link'   => $config['link']['name'],
            'params' => $config['link']['params'] ?? [],
            'type'   => $config['type'] ?? 'list',
            'icon'   => $config['icon'] ?? '',
            'active' => $this->isActive($config['link'], $currentPage),
        ];

        if (!empty($config['submenu'])) {
            $item['submenu'] = array_map(fn ($submenu) => $this->buildMenuItem($submenu, $currentPage), $config['submenu']);
        }

        return $item;
    }

    private function getHeaderNavigationConfig(): array
    {
        return file_exists(ConstantConfig::FILEPATH_CONFIG_HEADER_NAVIGATION)
            ? json_decode(file_get_contents(ConstantConfig::FILEPATH_CONFIG_HEADER_NAVIGATION), true)
            : [];
    }

    private function isActive(array $link, string $currentPage): bool
    {
        if (empty($link['name'])) {
            return false;
        }

        $path = '/' . ltrim($link['name'], '/');

        if ($path === '/index') {
            $path = '/';
        }

        if (!empty($link['params'])) {
            $path .= '/' . implode('/', array_values($link['params']));
        }

        return rtrim($currentPage, '/') === rtrim($path, '/');
    }

    // Footer Navigation
    public function footerNavigation(): array
    {
        $menuConfig = $this->getFooterNavigationConfig();
        if (!$menuConfig) {
            return [];
        }

        uasort($menuConfig, fn ($a, $b) => ($a['order'] ?? 999) <=> ($b['order'] ?? 999));

        return array_map(fn ($config) => $this->buildFooterItem($config), $menuConfig);
    }

    private function buildFooterItem(array $config): array
    {
        return [
            'title'  => $this->translation->trans($config['link']['title']),
            'link'   => $config['link']['name'],
            'params' => $config['link']['params'] ?? []
        ];
    }

    private function getFooterNavigationConfig(): array
    {
        return file_exists(ConstantConfig::FILEPATH_CONFIG_FOOTER_NAVIGATION)
            ? json_decode(file_get_contents(ConstantConfig::FILEPATH_CONFIG_FOOTER_NAVIGATION), true)
            : [];
    }

    // User Navigation
    public function userNavigation(int $sessionUserId): ?object
    {
        $sanitize = new SanitizeUtility();

        try {
            $query = "SELECT user.login, user_details.avatar, user_details.fullname, user.roles AS permission
                FROM dbm_user user
                INNER JOIN dbm_user_details user_details ON user_details.user_id = user.id
                WHERE user.id = :uid";

            if (!$this->database->queryExecute($query, [':uid' => $sessionUserId])) {
                throw new Exception("Błąd podczas pobierania danych użytkownika.");
            }

            $data = $this->database->fetchObject();

            if (!$data) {
                throw new UserNotFoundException();
            }

            $data->avatar = !empty($data->avatar) ? $sanitize->sanitizeView($data->avatar) : 'no-avatar.png';
            $data->login = !empty($data->login) ? $sanitize->sanitizeView($data->login) : 'NoName';
            $data->fullname = !empty($data->fullname) ? $sanitize->sanitizeView($data->fullname) : 'NoName';

            if (!in_array($data->permission, ConstantConfig::USER_ROLES, true)) {
                $data->permission = ConstantConfig::USER_ROLES['G'];
            }

            return $data;
        } catch (Exception $e) {
            $this->logger->critical($e->getMessage(), ['exception' => $e]);
            return null;
        }
    }
}
