<?php

$installClasses = ['InstallController::class'];

$installUses = <<<PHP
use App\\Controller\\InstallController;
PHP;

$installRoutes = <<<PHP
// Install routes
    \$router->addRoute('/install', [InstallController::class, 'install'], 'install');
PHP;

$installValues = '';
