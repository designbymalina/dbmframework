<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Controller;

use App\Config\ConstantConfig;
use App\Service\InstallService;
use Dbm\Classes\BaseController;
use Dbm\Classes\Http\Request;
use Dbm\Interfaces\DatabaseInterface;
use Psr\Http\Message\ResponseInterface;

class InstallController extends BaseController
{
    private readonly InstallService $service;

    public function __construct(?DatabaseInterface $database = null)
    {
        parent::__construct($database);

        $this->service = new InstallService($database);
    }

    /**
     * @Route: "/install"
    */
    public function install(Request $request): ResponseInterface
    {
        $arraySteps = ConstantConfig::ARRAY_INSTALL_STEPS;
        $stepAction = $request->getQuery('action') ?? $arraySteps[1]['action'];

        $stepKey = (int) array_search($stepAction, array_column($arraySteps, 'action')) + 1;
        $progress = $arraySteps[$stepKey]['progress'] ?? 0;

        if ($stepAction !== $arraySteps[1]['action']) {
            $allMessages = $this->service->handleStepByStep($stepAction, $this->getDIContainer());
        }

        $stepNext = $arraySteps[$stepKey + 1]['action'] ?? null;
        $pathNext = $stepNext ? '?action=' . $stepNext : null;

        return $this->render("install/index.phtml", [
            'meta' => $this->service->getMetaInstall(),
            'install' => $this->service->isInstallationRemoved(),
            'progress' => $progress,
            'stepAction' => $stepAction,
            'stepKey' => $stepKey,
            'pathNext' => $pathNext,
            'allMessages' => $allMessages ?? null,
        ]);
    }
}
