<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Service;

use Dbm\Classes\Translation;

class IndexService
{
    private Translation $translation;

    public function __construct()
    {
        $this->translation = new Translation();
    }

    public function getMetaIndex(): array
    {
        return [
            'meta.title' => $this->translation->trans('index.index_meta_title'),
            'meta.description' => $this->translation->trans('index.index_meta_description'),
            'meta.keywords' => $this->translation->trans('index.index_meta_keywords'),
        ];
    }

    public function getMetaStart(): array
    {
        return [
            'meta.title' => $this->translation->trans('index.start_meta_title'),
            'meta.description' => $this->translation->trans('index.start_meta_description'),
            'meta.keywords' => $this->translation->trans('index.start_meta_keywords'),
            'meta.robots' => "noindex,nofollow",
        ];
    }

    public function getMetaInstaller(): array
    {
        return [
            'meta.title' => $this->translation->trans('index.installer_meta_title'),
            'meta.description' => $this->translation->trans('index.installer_meta_description'),
            'meta.keywords' => $this->translation->trans('index.installer_meta_keywords'),
            'meta.robots' => "noindex,nofollow",
        ];
    }

    public function alertMessage(array $msg): array
    {
        $map = [
            'success' => 'messageSuccess',
            'error' => 'messageDanger',
            'info' => 'messageInfo',
            'warning' => 'messageWarning',
        ];

        $type = $msg['type'] ?? 'info';
        $message = $msg['message'] ?? '';

        $alertType = $map[$type] ?? 'messageInfo';

        return [
            'type' => $alertType,
            'message' => $message,
        ];
    }
}
