<?php
/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace App\Service;

use App\Config\ConstantConfig;
use App\Model\InstallModel;
use App\Utility\InstallerUtility;
use Dbm\Classes\ExceptionHandler;
use Dbm\Classes\RouterSingleton;
use Dbm\Classes\Translation;
use Dbm\Interfaces\DatabaseInterface;
use Dbm\Interfaces\TranslationInterface;
use Lib\Files\FileSystem;
use BadMethodCallException;
use InvalidArgumentException;
use Exception;
use RuntimeException;

class InstallService
{
    private InstallModel $model;
    private TranslationInterface $translation;
    private InstallerUtility $installer;
    private FileSystem $fileSystem;

    public function __construct(?DatabaseInterface $database = null)
    {
        $this->translation = new Translation();
        $this->model = new InstallModel($database);
        $this->installer = new InstallerUtility();
        $this->fileSystem = new FileSystem();
    }

    public function getMetaInstall(): array
    {
        return [
            'meta.title' => $this->translation->trans('install.install_meta_title'),
            'meta.robots' => "noindex,nofollow",
        ];
    }

    /* TODO! Można rozszerzyć... */
    public function isInstallationRemoved(): bool
    {
        // 1. Sprawdzenie, czy klasa InstallController i pozostałe elementy zostały usuniete
        /* if (class_exists(\App\Controller\InstallController::class)) {
            return false; // Instalacja NIE została usunięta
        } */

        // 2. Sprawdzenie, czy ścieżka "install" istnieje w routerze
        try {
            $router = RouterSingleton::getInstance();
            $routes = $router->getRoutes();

            foreach ($routes as $route) {
                if (isset($route['name']) && $route['name'] === 'install') {
                    return true;
                }
            }
        } catch (Exception $e) {
            return false;
        }

        return false;
    }

    public function handleStepByStep(string $action, ?object $container = null): array
    {
        $availableActions = array_column(ConstantConfig::ARRAY_INSTALL_STEPS, 'action');

        if (!in_array($action, $availableActions, true)) {
            throw new InvalidArgumentException('This installation step is not available!');
        }

        $methodName = 'step' . str_replace(' ', '', ucwords(str_replace('_', ' ', $action)));

        if (!method_exists($this, $methodName)) {
            throw new BadMethodCallException('Installation method is not available!');
        }

        return $this->$methodName($container); // jeśli metoda nie potrzebuje $container, można go pominąć
    }

    /**
     * @internal Used by handleStepByStep()
     */
    private function stepCheckCMSLite(): array
    {
        $messages = [];
        $phpVersion = '8.1.0';

        // PHP Version
        if (version_compare(PHP_VERSION, $phpVersion, '>=')) {
            $messages[] = ['type' => "success", 'message' => "PHP version is compatible (>= $phpVersion)"];
        } else {
            $messages[] = ['type' => "danger", 'message' => "PHP version must be >= $phpVersion"];
        }

        // Required extensions
        $requiredExtensions = ['pdo', 'pdo_mysql', 'session', 'json'];

        foreach ($requiredExtensions as $ext) {
            $messages[] = extension_loaded($ext)
                ? ['type' => "success", 'message' => "Extension $ext loaded"]
                : ['type' => "danger", 'message' => "Missing PHP extension: $ext"];
        }

        // Translations config
        try {
            if ($this->isConfigLanguage()) {
                $messages[] = ['type' => "success", 'message' => 'Language configuration valid'];
            }
        } catch (ExceptionHandler $e) {
            $messages[] = ['type' => "danger", 'message' => $e->getMessage()];
        }

        // Database config
        $messages[] = $this->isConfigDatabase()
            ? ['type' => "success", 'message' => 'Database configuration is complete']
            : ['type' => "danger", 'message' => 'Missing database configuration in .env'];

        return $messages;
    }

    /**
     * @internal Used by handleStepByStep()
     */
    private function stepCreateCMSLite(): array
    {
        $dirModule = BASE_DIRECTORY . '_Documents' . DS . 'CMSLite';
        $pathZip = $dirModule . '.zip';
        $pathManifest = $dirModule . DS . 'module.json';

        $messages = [];

        $msgInstall = $this->installer->installModule($dirModule, $pathManifest, $pathZip);

        if (!empty($msgInstall)) {
            if ($msgInstall['type'] === 'success') {
                $msgInstall['message'] .= $this->translation->trans('install.alert.step.cmslite_created');
            }

            $messages[] = $msgInstall;
        }

        return $messages;
    }

    /**
     * @internal Used by handleStepByStep()
     */
    private function stepCreateTable(): array
    {
        return $this->importDatabase()
            ? [['type' => "success", 'message' => $this->translation->trans('install.alert.database_import_success')]]
            : [['type' => "danger", 'message' =>  $this->translation->trans('install.alert.database_already_exists')]];
    }

    /**
     * @internal Used by handleStepByStep()
     */
    private function stepCreateAuthentication(): array
    {
        $dirModule = BASE_DIRECTORY . '_Documents' . DS . 'Authentication';
        $pathZip = $dirModule . '.zip';
        $pathManifest = $dirModule . DS . 'module.json';

        $messages = [];

        $msgInstall = $this->installer->installModule($dirModule, $pathManifest, $pathZip);

        if (!empty($msgInstall)) {
            if ($msgInstall['type'] === 'success') {
                $msgInstall['message'] .= $this->translation->trans('install.alert.step.authentication_created');
            }

            $messages[] = $msgInstall;
        }

        return $messages;
    }

    /**
     * @internal Used by handleStepByStep()
     */
    private function stepCreateAdminPanel(): array
    {
        $dirModule = BASE_DIRECTORY . '_Documents' . DS . 'AdminPanel';
        $pathZip = $dirModule . '.zip';
        $pathManifest = $dirModule . DS . 'module.json';

        $messages = [];

        $msgInstall = $this->installer->installModule($dirModule, $pathManifest, $pathZip);

        if (!empty($msgInstall)) {
            if ($msgInstall['type'] === 'success') {
                $msgInstall['message'] .= $this->translation->trans('install.alert.step.admin_panel_created');
            }

            $messages[] = $msgInstall;
        }

        return $messages;
    }

    /**
     * TODO! Można zmienić rozbudować komunikaty.
     * Klasa nie odróżnia różnych typów konunikatów, tylko success lub danger (wszystko inne).
     */
    private function stepFinish(): array
    {
        $dirModule = BASE_DIRECTORY . '_Documents' . DS . 'install';
        $pathZip = $dirModule . '.zip';
        $fileHeader = 'header.phtml';
        $headerPath = BASE_DIRECTORY . 'templates' . DS . '_include' . DS . $fileHeader;
        $dirBackup = BASE_DIRECTORY . '_Documents' . DS . 'BackupBaseFiles' . DS . 'templates' . DS . '_include' . DS . $fileHeader;
        $dirCMSLite = BASE_DIRECTORY . '_Documents' . DS . 'CMSLite';
        $dirAuthentication = BASE_DIRECTORY . '_Documents' . DS . 'Authentication';
        $dirAdminPanel = BASE_DIRECTORY . '_Documents' . DS . 'AdminPanel';
        $messages = [];

        $routesPath = BASE_DIRECTORY . 'application' .  DS . 'routes.php';

        if (file_exists($routesPath)) {
            $content = file_get_contents($routesPath);
            if ($content !== false) {
                $content = preg_replace("/\\s*use\\s+App\\\\Controller\\\\InstallController;\\s*/", "\n", $content);
                $content = preg_replace("/\\s*\\\$router->addRoute\\('\\/install', \\[InstallController::class, 'install'\\], 'install'\\);\\s*/", "", $content);

                $this->fileSystem->editFile($routesPath, $content);
                // $messages[] = ['type' => 'success', 'message' => 'Updated routes.php successfully.'];
            } else {
                $messages[] = ['type' => 'error', 'message' => 'Failed to read routes.php.'];
            }
        } else {
            $messages[] = ['type' => 'error', 'message' => 'File routes.php does not exist.'];
        }

        if (file_exists($pathZip)) {
            $pathZipNew = BASE_DIRECTORY . '_Documents' . DS . 'off_install.zip';

            try {
                $this->fileSystem->renameFile($pathZip, $pathZipNew);
                // $messages[] = ['type' => 'success', 'message' => 'Renamed install.zip to off_install.zip.'];
            } catch (RuntimeException $e) {
                $messages[] = ['type' => 'error', 'message' => $e->getMessage()];
            }
        } else {
            $messages[] = ['type' => 'warning', 'message' => 'install.zip not found.'];
        }

        if (file_exists($headerPath)) {
            $content = file_get_contents($headerPath);

            if ($content !== false) {
                $content = preg_replace(
                    '/\\s*<!-- INFO:.*?-->\\s*\\{\\% include .*?start_navbar\\.phtml\' \\%\\}\\s*/s',
                    '',
                    $content
                );

                try {
                    $this->fileSystem->copyFile($headerPath, $dirBackup);
                    $this->fileSystem->editFile($headerPath, $content);
                    // $messages[] = ['type' => 'success', 'message' => 'Removed install header block from header.phtml.'];
                } catch (RuntimeException $e) {
                    $messages[] = ['type' => 'error', 'message' => $e->getMessage()];
                }
            } else {
                $messages[] = ['type' => 'error', 'message' => 'Unable to read header.phtml.'];
            }
        } else {
            $messages[] = ['type' => 'warning', 'message' => 'header.phtml file not found.'];
        }

        if (is_dir($dirModule)) {
            $this->fileSystem->deleteDirectory($dirModule);
            // $messages[] = ['type' => 'success', 'message' => 'Deleted install directory.'];
        } else {
            $messages[] = ['type' => 'warning', 'message' => 'Install directory not found.'];
        }

        if (is_dir($dirCMSLite)) {
            $this->fileSystem->deleteDirectory($dirCMSLite);
            // $messages[] = ['type' => 'success', 'message' => 'Deleted install directory.'];
        } else {
            $messages[] = ['type' => 'warning', 'message' => 'CMSLite directory not found.'];
        }

        if (is_dir($dirAuthentication)) {
            $this->fileSystem->deleteDirectory($dirAuthentication);
            // $messages[] = ['type' => 'success', 'message' => 'Deleted install directory.'];
        } else {
            $messages[] = ['type' => 'warning', 'message' => 'Authentication directory not found.'];
        }

        if (is_dir($dirAdminPanel)) {
            $this->fileSystem->deleteDirectory($dirAdminPanel);
            // $messages[] = ['type' => 'success', 'message' => 'Deleted install directory.'];
        } else {
            $messages[] = ['type' => 'warning', 'message' => 'AdminPanel directory not found.'];
        }

        $messages[] = ['type' => 'success', 'message' => $this->translation->trans('install.alert.step.finished')];
        return $messages;
    }

    private function isConfigLanguage(): bool
    {
        $appLanguages = getenv('APP_LANGUAGES');

        if ($appLanguages !== false && trim($appLanguages) !== '') {
            if (!preg_match('/^([A-Z]{2})(\\|[A-Z]{2})*$/', $appLanguages)) {
                throw new ExceptionHandler("Configuration error: APP_LANGUAGES contains an invalid format. Expected e.g. 'PL' or 'PL|EN|DE'.");
            }
        }

        return true;
    }

    private function isConfigDatabase(): bool
    {
        if (empty(getenv('DB_HOST')) || empty(getenv('DB_NAME')) || empty(getenv('DB_USER'))) {
            return false;
        }
        return true;
    }

    public function importDatabase(): bool
    {
        if ($this->model->isDatabaseInstalled('dbm_user')) {
            return false;
        }

        $sqlFilePath = __DIR__ . '/../../_Documents/Database/dbm_cms.sql';
        return $this->model->importDataFromFile($sqlFilePath);
    }
}
