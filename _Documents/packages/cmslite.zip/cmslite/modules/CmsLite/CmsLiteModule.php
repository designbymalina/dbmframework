<?php

/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite;

use Dbm\Core\DependencyContainer;
use Dbm\Core\Module\PluginModule;
use Dbm\Http\Message\Request;
use Dbm\Infrastructure\Log\Logger;
use Dbm\Localization\Contracts\TranslationInterface;
use Dbm\Routing\Contracts\UrlGeneratorInterface;
use Dbm\Routing\RouteBuilder;
use Dbm\Views\TemplateEngine;
use Mod\CmsLite\Controller\CmsLiteController;
use Mod\Shared\Utility\NavigationUtility;

final class CmsLiteModule extends PluginModule
{
    public function registerRoutes(RouteBuilder $routes): void
    {
        // Overwriting the home page
        $routes->get('/', [CmsLiteController::class, 'index'], 'home');

        // CMS Lite pages
        $routes->get('/{slug}', [CmsLiteController::class, 'show'], 'info_show');
        $routes->get('/info/{slug}', [CmsLiteController::class, 'show'], 'info_subpage');

        // CMS Lite home page forms
        $routes->post('/ajax-contact', [CmsLiteController::class, 'ajaxContact'], 'ajax_contact');
        $routes->post('/ajax-newsletter', [CmsLiteController::class, 'ajaxNewsletter'], 'ajax_newsletter');
    }

    public function register(DependencyContainer $container): void
    {
        $container->singleton(
            NavigationUtility::class,
            fn($c) => new NavigationUtility(
                $c->get(TranslationInterface::class),
                $c->get(Logger::class),
                $c->get(UrlGeneratorInterface::class)
            )
        );
    }

    public function boot(): void
    {
        $view = $this->container->get(TemplateEngine::class);
        $request = $this->container->get(Request::class);

        $view->setGlobal(
            'headerNavigation',
            fn() => $this->container
                    ->get(NavigationUtility::class)
                    ->getHeader($request->getUri()->getPath())
        );

        $view->setGlobal(
            'footerNavigation',
            fn() => $this->container
                ->get(NavigationUtility::class)
                ->getFooter($request->getUri()->getPath())
        );
    }
}
