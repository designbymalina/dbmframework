<?php

/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Controller;

use Dbm\Content\Flatfile\DataFlatfile;
use Dbm\Http\Controller\BaseController;
use Dbm\Http\Message\Request;
use Dbm\Http\Message\Response;
use Dbm\Infrastructure\Log\Logger;
use Dbm\Localization\LanguageService;
use Dbm\Support\Traits\LazyLoaderTrait;
use Lib\Sender\PHPMailerSender;
use Mod\CmsLite\Service\CmsLiteService;
use Mod\CmsLite\Form\CmsLiteContactForm;
use Mod\CmsLite\Model\CmsLiteModel;
use Psr\Http\Message\ResponseInterface;
use Exception;
use Throwable;

final class CmsLiteController extends BaseController
{
    use LazyLoaderTrait;

    private ?Logger $logger = null;
    private ?PHPMailerSender $mailer;

    protected function service(): CmsLiteService
    {
        return $this->lazy(
            'service',
            fn()
            => new CmsLiteService(
                $this->model(),
                $this->translation(),
                $this->logger(),
                $this->mailer()
            )
        );
    }

    protected function model(): CmsLiteModel
    {
        return $this->lazy(
            'model',
            fn() => new CmsLiteModel(
                $this->dataFlatfile()
            )
        );
    }

    protected function dataFlatfile(): DataFlatfile
    {
        return $this->lazy(
            'dataFlatfile',
            fn() => new DataFlatfile(
                $this->request(),
                $this->logger(),
                $this->languageService()
            )
        );
    }

    protected function languageService(): LanguageService
    {
        return $this->lazy(
            'languageService',
            fn() => new LanguageService(
                $this->request(),
                $this->cookie()
            )
        );
    }

    protected function logger(): Logger
    {
        return $this->lazy('logger', fn() => new Logger());
    }

    protected function mailer(): PHPMailerSender
    {
        return $this->lazy('mailer', fn() => new PHPMailerSender());
    }

    /**
     * Index page
     * @routing GET '/' name: index
     *
     * @return ResponseInterface
     */
    public function index(): ResponseInterface
    {
        try {
            return $this->render('cmslite/index.phtml', [
                'meta' => $this->service()->getMetaIndex(),
            ]);
        } catch (Throwable $e) {
            $this->logger()->error('Template rendering error in ' . __METHOD__, ['exception' => $e]);
            throw $e;
        }
    }

    /**
     * Show page
     * @routing GET '/show' name: show
     *
     * @return ResponseInterface
     */
    public function show(string $slug): ResponseInterface
    {
        try {
            $result = $this->service()->renderPageContent($slug);

            if (!$result->isSuccess()) {
                $this->setFlash($result->getError(), 'messageWarning');
            }

            return $this->render('cmslite/show.phtml', [
                'meta' => $this->service()->getMetaPage($slug),
                'content' => $result->getData(),
            ]);
        } catch (Throwable $e) {
            $this->logger()->error('Template rendering error in ' . __METHOD__, ['exception' => $e]);
            throw $e;
        }
    }

    /**
     * Handle contact form submission via AJAX.
     * @routing POST '/ajax-contact' name: ajax_contact
     *
     * @param Request $request
     * @param Logger $logger
     * @return ResponseInterface
     */
    public function ajaxContact(Request $request, Logger $logger): ResponseInterface
    {
        try {
            if (!$request->isMethod('POST')) {
                return Response::text("Invalid request method.", 405);
            }

            $bodyParams = (array) $request->getParsedBody();

            if (!$this->csrfToken($bodyParams)) {
                return Response::text("Invalid CSRF token.", 403);
            }

            $validator = new CmsLiteContactForm();
            $errors = $validator->validate($bodyParams);

            if (!empty($errors)) {
                return Response::text("Invalid form data.", 422);
            }

            $isSent = $this->service()->makeContactMessage($bodyParams);

            if ($isSent) {
                return Response::text("OK", 200); // JS expects "OK"
            } else {
                return Response::text("Failed to send message. Please try again.", 500);
            }
        } catch (Exception $exception) {
            $logger->critical($exception->getMessage(), ['exception' => $exception]);
            return Response::text("An error occurred while processing your request.", 500);
        }
    }

    /**
     * Newsletter form
     * @routing POST '/ajax-newsletter' name: ajax_newsletter
     *
     * @param Request $request
     * @param Logger $logger
     * @return ResponseInterface
     */
    public function ajaxNewsletter(Request $request, Logger $logger): ResponseInterface
    {
        try {
            if (!$request->isMethod('POST')) {
                return Response::text("Invalid request method.", 405);
            }

            // INFO: Add newsletter subscription logic here.
            return Response::text("OK", 200); // JS expects "OK"
        } catch (Exception $exception) {
            $logger->critical($exception->getMessage(), ['exception' => $exception]);
            return Response::text("An error occurred while processing your request.", 500);
        }
    }
}
