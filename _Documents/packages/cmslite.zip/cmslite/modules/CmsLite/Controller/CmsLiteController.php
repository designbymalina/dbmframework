<?php

/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Controller;

use Dbm\Http\Controller\BaseController;
use Dbm\Http\Message\Request;
use Dbm\Http\Message\Response;
use Dbm\Infrastructure\Log\Logger;
use Dbm\Security\CsrfTokenManager;
use Dbm\Views\Flash\FlashBag;
use Mod\CmsLite\Service\CmsLiteService;
use Mod\CmsLite\Form\CmsLiteContactForm;
use Psr\Http\Message\ResponseInterface;
use Exception;
use Throwable;

final class CmsLiteController extends BaseController
{
    public function __construct(
        private readonly CmsLiteService $service,
        private readonly Logger $logger,
        private readonly FlashBag $flash,
        private readonly CsrfTokenManager $csrf
    ) {}

    /**
     * Index page
     * @routing GET '/' name: index
     *
     * @return ResponseInterface
     */
    public function index(): ResponseInterface
    {
        try {
            $metaData = $this->service->getMetaIndex();
            $this->trackActivity($metaData);

            return $this->render('cmslite/index.phtml', [
                'meta' => $metaData,
            ]);
        } catch (Throwable $exception) {
            $this->logger->error(
                'Template rendering error in ' . __METHOD__,
                ['exception' => $exception]
            );

            throw $exception;
        }
    }

    /**
     * Show page
     * @routing GET '/show' name: show
     *
     * @return ResponseInterface
     */
    public function show(string $slug): ResponseInterface
    {
        try {
            $result = $this->service->renderPageContent($slug);

            if (!$result->isSuccess()) {
                $this->flash->set($result->getError(), 'messageWarning');
            }

            $metaData = $this->service->getMetaPage($slug);
            $this->trackActivity($metaData);

            return $this->render('cmslite/show.phtml', [
                'meta' => $metaData,
                'content' => $result->getData(),
            ]);
        } catch (Throwable $exception) {
            $this->logger->error(
                'Template rendering error in ' . __METHOD__,
                ['exception' => $exception]
            );

            throw $exception;
        }
    }

    /**
     * Handle contact form submission via AJAX.
     * @routing POST '/ajax-contact' name: ajax_contact
     *
     * @param Request $request
     * @return ResponseInterface
     */
    public function ajaxContact(Request $request): ResponseInterface
    {
        try {
            $bodyParams = (array) $request->getParsedBody();

            if (!$this->csrf->isValid($bodyParams['csrf_token'] ?? '')) {
                return Response::text("Invalid CSRF token.", 403);
            }

            $validator = new CmsLiteContactForm();
            $errors = $validator->validate($bodyParams);

            if (!empty($errors)) {
                return Response::text("Invalid form data.", 422);
            }

            $isSent = $this->service->makeContactMessage($bodyParams);

            if ($isSent) {
                return Response::text("OK", 200);
            } else {
                return Response::text("Failed to send message. Please try again.", 500);
            }
        } catch (Exception $exception) {
            $this->logger->critical($exception->getMessage(), ['exception' => $exception]);
            return Response::text("An error occurred while processing your request.", 500);
        }
    }

    /**
     * Newsletter form
     * @routing POST '/ajax-newsletter' name: ajax_newsletter
     *
     * @param Request $request
     * @return ResponseInterface
     */
    public function ajaxNewsletter(Request $request): ResponseInterface
    {
        try {
            if (!$request->isMethod('POST')) {
                return Response::text("Invalid request method.", 405);
            }

            // INFO: Add newsletter subscription logic here.
            return Response::text("OK", 200);
        } catch (Exception $exception) {
            $this->logger->critical($exception->getMessage(), ['exception' => $exception]);
            return Response::text("An error occurred while processing your request.", 500);
        }
    }

    // ===== Helpers =====

    /**
     * @param array<string, string> $metaData
     */
    private function trackActivity(array $metaData): void
    {
        $pageTitle = $metaData['meta.title'] ?? 'NoTitle';
        $userId = $this->getUserId();

        $this->service->activityMonitor($pageTitle, $userId);
    }
}
