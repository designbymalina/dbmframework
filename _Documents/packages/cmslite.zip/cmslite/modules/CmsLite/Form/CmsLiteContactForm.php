<?php

/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Form;

use Dbm\Validation\Validator;

class CmsLiteContactForm extends Validator
{
    /**
     * Validate the contact form data.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function validate(array $data): array
    {
        $data = $this->normalize($data);

        return $this->rules([
            'dbm_name' => ['required', 'string', 'regex:/^[\pL \'-]*$/u', 'min:2', 'max:60'],
            'dbm_email' => ['required', 'email'],
            'dbm_subject' => ['required', 'max:120'],
            'dbm_message' => ['required', 'max:2000'],
        ], $data);
    }
}
