<?php

/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Model;

use Dbm\Content\Flatfile\DataFlatfile;
use Dbm\Content\Flatfile\Dto\FileOperationDto;

final class CmsLiteModel
{
    public function __construct(
        private readonly DataFlatfile $datafile
    ) {}

    public function title(string $slug): string
    {
        return $this->meta('title', $slug);
    }

    public function description(string $slug): string
    {
        return $this->meta('description', $slug);
    }

    public function keywords(string $slug): string
    {
        return $this->meta('keywords', $slug);
    }

    public function content(string $slug): FileOperationDto
    {
        return $this->datafile->dataFlatFile('content', $slug);
    }

    public function fileName(string $slug): string
    {
        return $this->datafile->buildFileName($slug, 'html');
    }

    private function meta(string $type, string $slug): string
    {
        return (string) $this->datafile->dataFlatFile($type, $slug)->getData();
    }
}
