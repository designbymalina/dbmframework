<?php

/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\CmsLite\Service;

use Dbm\Content\Flatfile\Dto\FileOperationDto;
use Dbm\Infrastructure\Log\Logger;
use Dbm\Libraries\Sender\PHPMailerSender;
use Dbm\Localization\Contracts\TranslationInterface;
use Mod\CmsLite\Model\CmsLiteModel;
use Mod\Shared\Utility\ActivityMonitorUtility;
use Exception;

final class CmsLiteService
{
    private int $cacheTtl;

    public function __construct(
        private readonly CmsLiteModel $model,
        private readonly TranslationInterface $translation,
        private readonly Logger $logger,
        private readonly PHPMailerSender $mailer,
        private readonly ActivityMonitorUtility $activityMonitor
    ) {
        $ttl = getenv('CMS_CACHE_TTL');
        $this->cacheTtl = is_numeric($ttl) ? (int) $ttl : 3600;
    }

    /**
     * @return array<string, string>
     */
    public function getMetaIndex(): array
    {
        return [
            'meta.title' => $this->translation->trans('index.index_meta_title'),
            'meta.description' => $this->translation->trans('index.index_meta_description'),
            'meta.keywords' => $this->translation->trans('index.index_meta_keywords'),
        ];
    }

    /**
     * @return array<string, string>
     */
    public function getMetaPage(string $slug): array
    {
        return [
            'meta.title' => $this->model->title($slug),
            'meta.description' => $this->model->description($slug),
            'meta.keywords' => $this->model->keywords($slug),
        ];
    }

    /**
     * @param array<string> $data
     */
    public function makeContactMessage(array $data): bool
    {
        try {
            if (!$this->sendContactMessage($data)) {
                throw new Exception("An unexpected error occurred! Message could not be sent.");
            }

            return true;
        } catch (Exception $exception) {
            $this->logger->critical($exception->getMessage(), ['exception' => $exception]);
            return false;
        }
    }

    public function renderPageContent(string $slug): FileOperationDto
    {
        $cacheFile = BASE_DIRECTORY . '/var/cache/cmslite/' . $this->model->fileName($slug);

        if ($this->isCacheValid($cacheFile)) {
            return new FileOperationDto(true, file_get_contents($cacheFile));
        }

        $result = $this->model->content($slug);

        if ($result->isSuccess() && $this->isProduction()) {
            $this->storeCache($cacheFile, $result->getData());
        }

        return $result;
    }

    public function activityMonitor(string $title, int $userId): void
    {
        $user = $userId > 0 ? 'User' : null; // INFO! You can change this to username.

        $this->activityMonitor->logActivity($title, $user);
    }

    // --- Helpers ---

    /**
     * @param array<string> $data
     */
    private function sendContactMessage(array $data): bool
    {
        return $this->mailer->sendMessage([
            'subject' => $data['dbm_subject'],
            'sender_name' => $data['dbm_name'],
            'sender_email' => $data['dbm_email'],
            'recipient_name' => getenv('MAIL_FROM_NAME'),
            'recipient_email' => getenv('MAIL_FROM_EMAIL'),
            'message_content' => $data['dbm_message'],
        ]);
    }

    private function isProduction(): bool
    {
        return getenv('APP_ENV') === 'production';
    }

    private function isCacheValid(string $file): bool
    {
        return $this->isProduction()
            && is_file($file)
            && filemtime($file) + $this->cacheTtl > time();
    }

    private function storeCache(string $file, string $content): void
    {
        if (!is_dir(dirname($file))) {
            mkdir(dirname($file), 0o755, true);
        }

        file_put_contents($file, $content);
    }
}
