<?php

/**
 * Module: DbM Admin
 * Comprehensive administration panel designed for efficient system management and resource configuration.
 *
 * This software is proprietary and licensed.
 * Use of this software is subject to the terms of the DbM Platform License.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina
 * @license Proprietary
 *
 * @see /LICENSE_DBM_PLATFORM.txt
 * @link https://www.dbm.org.pl
 *
 * Example of use in controller:
 * $this->activityMonitor->logActivity($pageTitle, $userName);
 */

declare(strict_types=1);

namespace Mod\Shared\Utility;

class ActivityMonitorUtility
{
    private const DIR_DATA = BASE_DIRECTORY . '/data/json/';
    private const LOG_FILE = 'activity_monitor.json';
    private const EXPIRATION_TIME = 604800; // 7 dni w sekundach

    private string $logFilePath;

    public function __construct()
    {
        if (!is_dir(self::DIR_DATA)) {
            mkdir(self::DIR_DATA, 0o777, true);
        }

        $this->logFilePath = self::DIR_DATA . self::LOG_FILE;

        if (!file_exists($this->logFilePath)) {
            file_put_contents($this->logFilePath, json_encode([]));
        }
    }

    /**
     * Rejestruje aktywność użytkownika lub gościa na stronie.
     */
    public function logActivity(string $title, ?string $user = null): void
    {
        $user ??= 'Guest';
        $now = time();

        $currentData = $this->getAllActivities();
        $updated = false;

        foreach ($currentData as &$activity) {

            if ($activity['title'] === $title && $activity['user'] === $user) {

                // TOTAL zawsze rośnie
                $activity['total'] = ($activity['total'] ?? 0) + 1;

                // 7 dni rolling window
                if (($now - $activity['timestamp']) > self::EXPIRATION_TIME) {
                    $activity['visit'] = 1;
                } else {
                    $activity['visit']++;
                }

                $activity['timestamp'] = $now;
                $updated = true;
                break;
            }
        }

        if (!$updated) {
            $currentData[] = [
                'title' => $title,
                'user' => $user,
                'visit' => 1,
                'total' => 1,
                'timestamp' => $now,
            ];
        }

        $this->saveToFile($currentData);
    }

    /**
     * Formatuje dane dla szablonu, sortuje od najnowszych i ogranicza wynik.
     *
     * @return array<array<string, mixed>>
     */
    public function formatActivities(int $limit = 10): array
    {
        $currentData = $this->getAllActivities();
        $now = time();

        // filtrowanie – tylko ostatnie 7 dni
        $currentData = array_filter($currentData, fn($activity) => ($now - $activity['timestamp']) <= self::EXPIRATION_TIME);

        // sortowanie po czasie
        usort($currentData, fn($a, $b) => $b['timestamp'] <=> $a['timestamp']);

        $formatted = [];

        foreach (array_slice($currentData, 0, $limit) as $activity) {
            $formatted[] = [
                'title' => $activity['title'],
                'user' => $activity['user'],
                'visit' => $activity['visit'], // 7 dni
                'total' => $activity['total'] ?? 0, // od początku
                'time' => $this->timeAgo($now - $activity['timestamp']),
            ];
        }

        return $formatted;
    }

    /**
     * Zwraca łączną liczbę wszystkich wizyt (globalnie).
     */
    public function totalVisitsAllPages(): int
    {
        $currentData = $this->getAllActivities();
        $sum = 0;

        foreach ($currentData as $activity) {
            $sum += $activity['total'] ?? $activity['visit'] ?? 0;
        }

        return $sum;
    }

    /**
     * Pobiera wszystkie zapisane aktywności.
     *
     * @return array<array<string, mixed>>
     */
    public function getAllActivities(): array
    {
        $currentData = json_decode(file_get_contents($this->logFilePath), true);

        return is_array($currentData) ? $currentData : [];
    }

    /**
     * Zapisuje dane do pliku.
     *
     * @param array<array<string, mixed>> $data
     */
    private function saveToFile(array $data): void
    {
        file_put_contents($this->logFilePath, json_encode($data, JSON_PRETTY_PRINT));
    }

    /**
     * Przekształca różnicę czasu w czytelny format
     */
    private function timeAgo(int $seconds): string
    {
        if ($seconds < 60) {
            return "$seconds sek.";
        }

        if ($seconds < 3600) {
            $minutes = floor($seconds / 60);
            return "$minutes min";
        }

        if ($seconds < 86400) {
            $hours = floor($seconds / 3600);
            return "$hours godz.";
        }

        if ($seconds < 604800) {
            $days = floor($seconds / 86400);
            return "$days dni";
        }

        $weeks = floor($seconds / 604800);
        return "$weeks tydzień" . ($weeks > 1 ? "e" : "");
    }
}
