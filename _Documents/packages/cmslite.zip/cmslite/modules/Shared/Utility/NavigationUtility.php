<?php

/**
 * Application: DbM Framework
 * A lightweight PHP framework for building web applications.
 *
 * @author Artur Malinowski
 * @copyright Design by Malina (All Rights Reserved)
 * @license MIT
 * @link https://www.dbm.org.pl
 */

declare(strict_types=1);

namespace Mod\Shared\Utility;

use Dbm\Localization\Contracts\TranslationInterface;
use Dbm\Infrastructure\Log\Logger;
use Dbm\Routing\Contracts\UrlGeneratorInterface;

final class NavigationUtility
{
    // INFO! Można przebudować, np. dodać w Constants,
    // ale mieć na uwadze, że parametry są wspólne dla wszystkich modułów.
    public const HEADER_CONFIG = BASE_DIRECTORY . '/storage/navigation/header.json';
    public const FOOTER_CONFIG = BASE_DIRECTORY . '/storage/navigation/footer.json';

    /** @var array<string, array<string, array<int, array<string, mixed>>>> */
    private array $cache = [];

    public function __construct(
        private TranslationInterface $translator,
        private Logger $logger,
        private UrlGeneratorInterface $urlGenerator
    ) {}

    // === Public API ===

    /**
     * @return array<int, array<string, mixed>>
     */
    public function getHeader(string $currentPath): array
    {
        $currentPath = $this->resolvePath($currentPath);

        return $this->cache['header'][$currentPath] ??= $this->buildHeader($currentPath);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function getFooter(string $currentPath): array
    {
        $currentPath = $this->resolvePath($currentPath);

        return $this->cache['footer'][$currentPath] ??= $this->buildFooter($currentPath);
    }

    /**
     * Config loader
     *
     * @return array<int, array<string, mixed>>
     */
    private function loadConfig(string $path): array
    {
        if (!is_file($path)) {
            $this->logger->warning('Navigation config missing', ['file' => $path]);
            return [];
        }

        try {
            $json = file_get_contents($path);
            $data = json_decode($json, true, 512, JSON_THROW_ON_ERROR);

            return is_array($data) ? $data : [];
        } catch (\Throwable $e) {
            $this->logger->critical('Navigation config error', [
                'file' => $path,
                'exception' => $e,
            ]);

            return [];
        }
    }

    /**
     * Header
     *
     * @return array<int, array<string, mixed>>
     */
    private function buildHeader(string $currentPath): array
    {
        $config = $this->loadConfig(self::HEADER_CONFIG);
        uasort($config, fn($a, $b) => ($a['order'] ?? 999) <=> ($b['order'] ?? 999));

        return array_map(
            fn(array $item) => $this->mapItem(
                $item,
                $this->isActive($item['link'] ?? [], $currentPath)
            ),
            array_values($config)
        );
    }

    /**
     * Footer
     *
     * @return array<int, array<string, mixed>>
     */
    private function buildFooter(string $currentPath): array
    {
        $config = $this->loadConfig(self::FOOTER_CONFIG);
        uasort($config, fn($a, $b) => ($a['order'] ?? 999) <=> ($b['order'] ?? 999));

        return array_map(
            fn(array $item) => $this->mapItem(
                $item,
                $this->isActive($item['link'] ?? [], $currentPath)
            ),
            array_values($config)
        );
    }

    // === Helpers ===

    /**
     * @param array<string, mixed> $config
     * @return array<string, mixed>
     */
    private function mapItem(array $config, bool $active = false): array
    {
        $item = [
            'title' => $this->translator->trans($config['link']['title']),
            'link' => $config['link']['name'] ?? null,
            'params' => $config['link']['params'] ?? [],
            'type' => $config['type'] ?? 'list',
            'icon' => $config['icon'] ?? null,
            'active' => $active,
            'submenu' => [],
        ];

        if (!empty($config['submenu'])) {
            foreach ($config['submenu'] as $sub) {
                $item['submenu'][] = $this->mapItem($sub, false);
            }
        }

        return $item;
    }

    private function resolvePath(string $fullPath): string
    {
        $baseFolderName = basename(BASE_DIRECTORY);

        $path = parse_url($fullPath, PHP_URL_PATH) ?? '/';

        if (($pos = strpos($path, '/' . $baseFolderName . '/')) !== false) {
            $path = substr($path, $pos + strlen($baseFolderName) + 1);
        }

        return '/' . trim($path, '/');
    }

    /**
     * @param array<string, mixed> $link
     */
    private function isActive(array $link, string $currentPath): bool
    {
        if (empty($link['name'])) {
            return false;
        }

        try {
            $expectedPath = $this->urlGenerator->path(
                $link['name'],
                $link['params'] ?? []
            );

            $expectedPath = $this->resolvePath($expectedPath);
            $currentPath = $this->resolvePath($currentPath);
        } catch (\Throwable $e) {
            $this->logger->warning('Navigation URL generation failed', [
                'link' => $link,
                'exception' => $e,
            ]);
            return false;
        }

        return rtrim($expectedPath, '/') === rtrim($currentPath, '/');
    }
}
